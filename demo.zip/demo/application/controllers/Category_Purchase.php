<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_Purchase extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Category_Purchase_Model');
	 		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	 	}


	public function index()
	{

		$data['category_purchases']=$this->Category_Purchase_Model->get_all_category_purchases();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('category_purchases',$data);
		$this->load->view('footer');
	}
	public function category_purchase_add()
		{
			$created_date  = $this->input->post('created_date');
			$pcategory = $this->input->post('pcategory');
					
		
			$this->form_validation->set_rules('pcategory','Purchase Category', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
		echo json_encode(array("status" => TRUE));
		}
		else {
			$data = array(
					'created_date' => $this->input->post('created_date'),
					'pcategory' => $this->input->post('pcategory'),
					
					
				);
				$insert = $this->Category_Purchase_Model->category_purchase_add($data);
			
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Category Added Successfully'.'</div>');
				echo json_encode(array("status" => TRUE));
			
		}
			
		}
		public function ajax_category_purchaseedit($id)
		{
			$data = $this->Category_Purchase_Model->get_by_id($id);
			echo json_encode($data);
		}

		public function category_purchase_update()
	{
			$created_date  = $this->input->post('created_date');
			$pcategory = $this->input->post('pcategory');
			
		
			$this->form_validation->set_rules('pcategory','category Category', 'required');
			
			
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Category_Purchase'));
		}
		else {
		$data = array(
					'created_date' => $this->input->post('created_date'),
					'pcategory' => $this->input->post('pcategory'),
				
					
				);

		$this->Category_Purchase_Model->category_purchase_update(array('category_purchase_id' => $this->input->post('category_purchase_id')), $data);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Category Updated Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
	}

	public function category_purchase_delete($id)
	{

		$this->Category_Purchase_Model->delete_by_id($id);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Category Deleted Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}



}
