<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item_Purchase extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Item_Purchase_Model');
	 		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	 	}


	public function index()
	{
		$data['item_purchases']=$this->Item_Purchase_Model->get_all_item_purchases();
		$this->load->model('Category_Purchase_Model');
		$data['category_purchases']=$this->Category_Purchase_Model->get_all_category_purchases();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('item_purchases',$data);
		$this->load->view('footer');
	}
	public function item_purchase_add()
		{
			$created_date  = $this->input->post('created_date');
			$pitemname = $this->input->post('pitemname');
			
			$pprice = $this->input->post('pprice');
			$pitemgst = $this->input->post('pitemgst');
			$category = $this->input->post('category');
					
		
			$this->form_validation->set_rules('pitemname','Item Name', 'required');
		
			$this->form_validation->set_rules('pprice','Item Price', 'required|numeric');
			$this->form_validation->set_rules('pitemgst','Item GST', 'required|numeric');
			$this->form_validation->set_rules('category','Item Category', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Item_Purchases'));
		}
		else {
			$data = array(
					'created_date' => $this->input->post('created_date'),
					'pitemname' => $this->input->post('pitemname'),
					'pitemdes' => $this->input->post('pitemdes'),
					'pprice' => $this->input->post('pprice'),
					'pitemgst' => $this->input->post('pitemgst'),
					'category' => $this->input->post('category'),
					
				);
				$insert = $this->Item_Purchase_Model->item_purchase_add($data);
			
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Item Added Successfully'.'</div>');
				echo json_encode(array("status" => TRUE));
			
		}
			
		}
		public function ajax_item_purchaseedit($id)
		{
			$data = $this->Item_Purchase_Model->get_by_id($id);
			echo json_encode($data);
		}

		public function item_purchase_update()
	{
			$created_date  = $this->input->post('created_date');
			$pitemname = $this->input->post('pitemname');
			
			$pprice = $this->input->post('pprice');
			$pitemgst = $this->input->post('pitemgst');
			$category = $this->input->post('category');		
		
			$this->form_validation->set_rules('pitemname','Item Name', 'required');
			
			$this->form_validation->set_rules('pprice','Item Price', 'required|numeric');
			$this->form_validation->set_rules('pitemgst','Item GST', 'required|numeric');
				$this->form_validation->set_rules('category','Item Category', 'required');
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Item_Purchases'));
		}
		else {
		$data = array(
					'created_date' => $this->input->post('created_date'),
					'pitemname' => $this->input->post('pitemname'),
					'pitemdes' => $this->input->post('pitemdes'),
					'pprice' => $this->input->post('pprice'),
					'pitemgst' => $this->input->post('pitemgst'),
					'category' => $this->input->post('category'),
					
				);

		$this->Item_Purchase_Model->item_purchase_update(array('item_purchase_id' => $this->input->post('item_purchase_id')), $data);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Item Updated Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
	}

	public function item_purchase_delete($id)
	{

		$this->Item_Purchase_Model->delete_by_id($id);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Item Deleted Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}



}
