<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProfileSettings extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->helper('url');
	 		$this->load->model('Profile_model');
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	}
	
	
	public function index()
	{
		$data=$this->Profile_model->get_by_id();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('profilesetting',$data);
		$this->load->view('footer');
	}
	public function update_admin()
		{
			//print_r($_POST);exit();
			$username = $this->input->post('username');
				$comp_name = $this->input->post('comp_name');
					$comp_add = $this->input->post('comp_add');
						$comp_gst = $this->input->post('comp_gst');
							$term_cond = $this->input->post('term_cond');
			
			$newpassword = $this->input->post('newpassword');
			$userfile = $this->input->post('userfile');
			$email = $this->input->post('email');
			$this->form_validation->set_rules('username','customer Name', 'required');
			$this->form_validation->set_rules('email','Email', 'required');
			if ($this->form_validation->run() == FALSE)
			 {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('ProfileSettings'));
			}
			else {
				if(($newpassword == NULL) && ($userfile == NULL))
				{
					$data = array('id' => $this->input->post('id'),
					'username' => $this->input->post('username'),
						'comp_name' => $this->input->post('comp_name'),
							'comp_add' => $this->input->post('comp_add'),
								'comp_gst' => $this->input->post('comp_gst'),
								'term_cond' => $this->input->post('term_cond'),
					'email' => $this->input->post('email'));
				
					
				}
				elseif (($newpassword == NULL) && (!$profile_upload=$this->input->post('userfile')))
				 {
					$filename = md5(uniqid(rand(), true));
					$config = array('upload_path' => 'uploads/admin','allowed_types' => "gif|jpg|png|jpeg",'file_name' => $filename);
					$this->load->library('upload', $config);
						if($this->upload->do_upload())
						{
							$file_data = $this->upload->data();
							$profile_upload = $file_data['file_name'];
						}
					
					$data = array(
					'id' => $this->input->post('id'),
					'username' => $this->input->post('username'),
					'email' => $this->input->post('email'),
					'comp_name' => $this->input->post('comp_name'),
					'comp_add' => $this->input->post('comp_add'),
					'comp_gst' => $this->input->post('comp_gst'),
					'term_cond' => $this->input->post('term_cond'),
					'admin_photo' => $profile_upload

				);
				}
				else{
					$encrypt_password = password_hash($newpassword,PASSWORD_DEFAULT);
					$filename = md5(uniqid(rand(), true));
					$config = array('upload_path' => 'uploads/admin','allowed_types' => "gif|jpg|png|jpeg",'file_name' => $filename);
					$this->load->library('upload', $config);
						if($this->upload->do_upload())
						{
							$file_data = $this->upload->data();
							$profile_upload = $file_data['file_name'];
						}
					$data = array(
					'id' => $this->input->post('id'),
					'username' => $this->input->post('username'),
					'password' => $encrypt_password,
					'email' => $this->input->post('email'),
					'comp_name' => $this->input->post('comp_name'),
					'comp_add' => $this->input->post('comp_add'),
					'comp_gst' => $this->input->post('comp_gst'),
					'term_cond' => $this->input->post('term_cond'),
					'admin_photo' => $profile_upload

				);
					
					}

			if($this->Profile_model->profile_update(array('id' => $this->input->post('id')), $data))
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Profile Updated Successfully'.'</div>');
				redirect(base_url('ProfileSettings'));
				
			}
			else
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-danger">Profile cannot be updated'.'</div>');
				redirect(base_url('ProfileSettings'));
			}

		}
			
		}
		public function change_password()
	{
		
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('change_password');
		$this->load->view('footer');
	}
	public function update_password()
		{
			//print_r($_POST);exit();
			$old_password=$this->input->post('old_password');
    		$new_password=$this->input->post('new_password');
    		$renew_password=$this->input->post('renew_password');
			$this->form_validation->set_rules('old_password', 'Password', 'trim|required');
    		$this->form_validation->set_rules('new_password', 'New Password', 'required|matches[renew_password]');
    		$this->form_validation->set_rules('renew_password', 'Retype Password', 'required');
			if ($this->form_validation->run() == FALSE)
			 {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('ProfileSettings/change_password'));
			}
			else {

				$old_status=$this->Profile_model->check_old_password();
				//print_r($old_status);exit();
				if($old_status){
				$hash_password = $old_status->password;
				$hash = password_verify($old_password,$hash_password);
				if ($hash) {
        		
				$encrypt_password = password_hash($new_password,PASSWORD_DEFAULT);
				$data = array('password' => $encrypt_password);
				
			if($this->Profile_model->profile_update(array('id' => '1'), $data))
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Password Changes Successfully'.'</div>');
				redirect(base_url('ProfileSettings/change_password'));
				
			}
			else
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-danger">Pasword cannot be changed'.'</div>');
				redirect(base_url('ProfileSettings/change_password'));
			}
		}
		else{
			$this->session->set_flashdata('successMessage','<div class="alert alert-danger">Incorrect Old Password'.'</div>');
				redirect(base_url('ProfileSettings/change_password'));
	}
		
		}

		}
			
		}
}