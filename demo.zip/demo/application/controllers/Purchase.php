<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->helper('url');
	 		$this->load->model('Purchase_model');
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	}
	
	public function index()
	{
		$data['vendor_purchases']=$this->Purchase_model->venderwise_purchase();
		$this->load->model('Vendor_model');
		$data['vendors']=$this->Vendor_model->get_all_vendors();
		//print_r($data);exit();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('purchases',$data);
		//$this->load->view('purchases');
		$this->load->view('footer');
	}
	public function purchase_now()
	{
		$this->load->model('Item_Sale_Model');
		$this->load->model('Vendor_model');
		$data['items']=$this->Item_Sale_Model->get_all_item_sales();
		$data['vendors']=$this->Vendor_model->get_all_vendors();
		$rows = $this->Purchase_model->no_of_rows();
		if($rows == 0){
			 $data['purchase_id']="PI0001";
		}
		else
		{
			$max_id=$this->Purchase_model->get_max_id();
			$large_purchase_id = $this->Purchase_model->get_purchase_id($max_id);
			$arr = substr($large_purchase_id,2,5);  
			$arr=str_pad($arr + 1, 4, 0, STR_PAD_LEFT);   
			$purchase_id="PI".$arr;
			$data['purchase_id']= $purchase_id;                    
		}
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('purchasesnow',$data);
		//$this->load->view('purchasesnow');
		$this->load->view('footer');
	}
	public function all_purchase()
	{
		$this->load->model('Purchase_model');
		$this->load->model('Vendor_model');
		$data['vendors']=$this->Vendor_model->get_all_vendors();
		$data['all_purchases']=$this->Purchase_model->get_all_purchase();
		//print_r($data);exit();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('all_purchases',$data);
		$this->load->view('footer');
	}
		public function purchase_add()
			{
				$this->load->model('Item_Sale_Model');
				//print_r($_POST);exit();
					$purchase_date = $this->input->post('purchase_date');
					$purchase_id = $this->input->post('purchase_id');
					$purchase_vendor = $this->input->post('purchase_vendor');
					$purchase_reference = $this->input->post('purchase_reference');
					$item_id = $this->input->post('item_id');
					$hsn_no = $this->input->post('hsn_no');
					$item_name = $this->input->post('item_name');
					$item_quantity = $this->input->post('item_quantity');
					$item_price = $this->input->post('item_price');
					$item_per = $this->input->post('item_per');
					$item_cgst_percentage = $this->input->post('item_cgst_percentage');
					$item_sgst_percentage = $this->input->post('item_sgst_percentage');
					$item_igst_percentage = $this->input->post('item_igst_percentage');
					$total_amount = $this->input->post('total_amount');
					$purchase_grand_total = $this->input->post('purchase_grand_total');
					$filename = md5(uniqid(rand(), true));
					$config = array('upload_path' => 'uploads/purchase','allowed_types' => "jpg|png|jpeg|docx|pdf",'max_size' => '2048','file_name' => $filename);
					$this->load->library('upload', $config);
					if(!($this->input->post('userfile'))){
					if($this->upload->do_upload())
					{
					$file_data = $this->upload->data();
					$purchase_upload = $file_data['file_name'];
					}
					}
					else
					{
					$this->session->set_flashdata('errorMessage','<div class="alert alert-success">Error while adding Purchase'.'</div>');
					$purchase_upload=$this->input->post('userfile');
					}
					
					
					$data = array(
					'purchase_date' => $this->input->post('purchase_date'),
					'purchase_id' => $this->input->post('purchase_id'),
					'purchase_vendor' => $this->input->post('purchase_vendor'),
					'purchase_reference' => $this->input->post('purchase_reference'),
					'total_items' => sizeof($item_id),		
					'sub_total' => $this->input->post('item_total'),
					'sgst_percentage' => $this->input->post('sgst_percentage'),
					'sgst_value' => $this->input->post('sgst_value'),
					'cgst_percentage' => $this->input->post('cgst_percentage'),
					'cgst_value' => $this->input->post('cgst_value'),
					'igst_percentage' => $this->input->post('igst_percentage'),
					'igst_value' => $this->input->post('igst_value'),
					'purchase_grand_total' => $this->input->post('sale_grand_total'),
					'purchase_upload' => $purchase_upload
					);
					if($insert = $this->Purchase_model->purchase_add($data))
					{
						for($i=0; $i<sizeof($item_id); $i++){
							$data1 = array(
							'purchase_id' => $this->input->post('purchase_id'),
							'created_date' => $this->input->post('purchase_date'),
							'item_id' => $item_id[$i],
							'hsn_no' => $hsn_no[$i],
							'item_name' =>$item_name[$i],		
							'item_quantity' => $item_quantity[$i],
							'item_price' => $item_price[$i],
							'item_per' => $item_per[$i],
							'item_cgst_percentage' => $item_cgst_percentage[$i],
							'item_sgst_percentage' => $item_sgst_percentage[$i],
							'item_igst_percentage' => $item_igst_percentage[$i],
							'total_amount' => $total_amount[$i]
							);
							if ($insert = $this->Purchase_model->purchase_item_add($data1)) {
							$this->session->set_flashdata('errorMessage','<div class="alert alert-success">Purchase Added Successfully'.'</div>');
							//$url="Purchase/purchase_print/".$purchase_id;
							$url="Purchase/all_purchase";
						}
						else
						{
						$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Error While Adding Purchase'.'</div>');
						$url="Purchase/all_purchase";
					}	
					
						}
						for($i=0; $i<sizeof($item_id); $i++){
							$item_current_Stock= $this->Purchase_model->get_itemstock_by_id($item_id[$i]);
							$new_stock=$item_current_Stock+$item_quantity[$i];
							$data2 = array(
							'current_stock' => $new_stock
							);
							 $this->Item_Sale_Model->item_sale_update(array('item_sale_id' => $item_id[$i]), $data2);
							 }
						redirect(base_url($url));
					
				}
					else
					{
						$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Error While Adding Purchase'.'</div>');
					}
			
			
			redirect(base_url('Purchase/all_purchase'));
		}
	public function purchase_vendordetailed()
	{
		$id = $this->input->get('vendors_id');
		//print_r($id);exit();
		$data['vendor_purchases_lists']=$this->Purchase_model->get_purchase_by_vendor_id($id);
		$this->load->model('Vendor_model');
		$data['vendors']=$this->Vendor_model->get_all_vendors();
		//print_r($data);exit();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('purchases_vendorwise',$data);
		//$this->load->view('purchases');
		$this->load->view('footer');
	}
	public function purchase_view()
	{
		$this->load->model('Purchase_model');
		$id = $this->input->get('purchase_id');
		$data['purchases']= $this->Purchase_model->get_by_id($id);
		//print_r($data);exit();
		$data['purchases_items']= $this->Purchase_model->get_by_id_from_itemwise_purchase($id);
		$this->load->model('Vendor_model');
		$data['vendors']=$this->Vendor_model->get_all_vendors();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('purchaseview',$data);
		$this->load->view('footer');
	}
	public function purchase_print($id1='')
	{
		$this->load->model('Purchase_model');
		if ($id1) {
			$id=$id1;
		}
		else
		{$id = $this->input->get('purchase_id');}
		
		$data['purchases']= $this->Purchase_model->get_by_id($id);
		//print_r($data);exit();
		$data['purchases_items']= $this->Purchase_model->get_by_id_from_itemwise_purchase($id);
		$this->load->model('Vendor_model');
		$data['vendors']=$this->Vendor_model->get_all_vendors();
		$this->load->view('header');
		$this->load->view('purchaseprint',$data);
		
	}
	public function exportCSV(){
		// file name
		$from_date = $this->input->post('from_date');
		$to_date = $this->input->post('to_date');
		$filename = 'purchase_'.date('Ymd').'.csv';
		$purchase = $this->Purchase_model->durationpurchase($from_date,$to_date);
		//print_r($sales);exit();
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-Type: application/csv; "); 
		
		// get data
		

		// file creation
		$file = fopen('php://output', 'w');
		$title=array("Purchase");
		fputcsv($file, $title);
		$header = array("S.No","Date","Purchase ID","Vendor No.","Reference","Number of Item Purchased","Sub Total Amount","SGST Percentage","SGST Value","CGST Percentage","CGST Value","IGST Percentage","IGST Value","Grand Total","Bill Uploded");
		fputcsv($file, $header);

		foreach ($purchase as $key=>$line){
		 fputcsv($file,$line);
		}

		fclose($file);
		exit;
		redirect(base_url('Purchase'));
	}
}