<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->helper('url');
	 	//$this->load->model('Customer_model');
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
		$this->load->model('Sales_model');
	}
	
	public function purchase_report()
	{	
		
	//	$data['customer_sales']=$this->Sales_model->customerwise_sales();
		//$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('navigation');
		$data="";
		$this->load->view('purchase_report',$data);
		//$this->load->view('customers');
		$this->load->view('footer');
	}
	public function sales_report()
	{	
		
	//	$data['customer_sales']=$this->Sales_model->customerwise_sales();
		//$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('navigation');
		$data="";
		$this->load->view('sales_report',$data);
		//$this->load->view('customers');
		$this->load->view('footer');
	}
}
?>