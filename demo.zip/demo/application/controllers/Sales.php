<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller {

	public function __construct() {
		parent::__construct();
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
		$this->load->model('Sales_model');
	}
	public function index()
	{
		$data['sales']=$this->Sales_model->get_all_sale();
		$this->load->model('Customer_model');	
	
		$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('sales',$data);
		$this->load->view('footer');
	}
	public function addsales()
	{
		$this->load->model('Item_Sale_Model');
		$this->load->model('Customer_model');	
		$data['items']=$this->Item_Sale_Model->get_all_item_sales();
		$data['customers']=$this->Customer_model->get_all_customers();
		$rows = $this->Sales_model->no_of_rows();
		if($rows == 0){
			 $data['sale_id']="0001/18-19";
			 $data['order_no']="ON0001";
		}
		else
		{
			$max_id=$this->Sales_model->get_max_id();
			$large_sale_id = $this->Sales_model->get_sale_id($max_id);
			$arr = substr($large_sale_id,0,4);  
			$arr=str_pad($arr + 1, 4, 0, STR_PAD_LEFT);  
			$sale_id=$arr."/18-19";
			$order_no="ON".$arr;
			$data['sale_id']= $sale_id;  
			$data['order_no']= $order_no;                    
		}
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('addsales',$data);
		$this->load->view('footer');
	}
	public function sales_add()
			{
				$this->load->model('Item_Sale_Model');
		$this->load->model('Purchase_model');
				//print_r($_POST);exit();
					$sale_date = $this->input->post('sale_date');
					$sale_id = $this->input->post('sale_id');
					$customer_id = $this->input->post('customer_id');
					$item_id = $this->input->post('item_id');
					$hsn_no = $this->input->post('hsn_no');
					$item_name = $this->input->post('item_name');
					$item_quantity = $this->input->post('item_quantity');
					$item_price = $this->input->post('item_price');
					$item_per = $this->input->post('item_per');
					$item_cgst_percentage = $this->input->post('item_cgst_percentage');
					$item_sgst_percentage = $this->input->post('item_sgst_percentage');
					$item_igst_percentage = $this->input->post('item_igst_percentage');
					$total_amount = $this->input->post('total_amount');
						
					
					$data = array(
					'sale_date' => $this->input->post('sale_date'),
					'sale_id' => $this->input->post('sale_id'),
					'order_no' => $this->input->post('order_no'),
					'eway_no' => $this->input->post('eway_no'),
					'vehicle_reg_no' => $this->input->post('vehicle_reg_no'),
					'site' => $this->input->post('site'),
					'customer_id' => $this->input->post('customer_id'),
					'total_items' => sizeof($item_id),
					'transpotation' => $this->input->post('transpotation'),
					'sub_total' => $this->input->post('item_total'),
					'sgst_percentage' => $this->input->post('sgst_percentage'),
					'sgst_value' => $this->input->post('sgst_value'),
					'cgst_percentage' => $this->input->post('cgst_percentage'),
					'cgst_value' => $this->input->post('cgst_value'),
					'igst_percentage' => $this->input->post('igst_percentage'),
					'igst_value' => $this->input->post('igst_value'),
					'sale_grand_total' => $this->input->post('sale_grand_total')
					
					);
					if($insert = $this->Sales_model->sale_add($data))
					{
						for($i=0; $i<sizeof($item_id); $i++){
							$data1 = array(
							'sale_id' => $this->input->post('sale_id'),
							'created_date' => $this->input->post('sale_date'),
							'item_id' => $item_id[$i],
							'hsn_no' => $hsn_no[$i],
							'item_name' =>$item_name[$i],		
							'item_quantity' => $item_quantity[$i],
							'item_price' => $item_price[$i],
							'item_per' => $item_per[$i],
							'item_cgst_percentage' => $item_cgst_percentage[$i],
							'item_sgst_percentage' => $item_sgst_percentage[$i],
							'item_igst_percentage' => $item_igst_percentage[$i],
							'total_amount' => $total_amount[$i]
							);
							if ($insert = $this->Sales_model->sale_item_add($data1)) {
							$this->session->set_flashdata('errorMessage','<div class="alert alert-success">Sales Added Successfully'.'</div>');
							//$url="Sales/sale_print/".$sale_id;
							$url="Sales";
						}
						else
						{
						$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Error While Adding Sales'.'</div>');
						$url="Sales";
					}	
					
						}
						for($i=0; $i<sizeof($item_id); $i++){
							$item_current_Stock= $this->Purchase_model->get_itemstock_by_id($item_id[$i]);
							$new_stock=$item_current_Stock-$item_quantity[$i];
							$data2 = array(
							'current_stock' => $new_stock
							);
							 $this->Item_Sale_Model->item_sale_update(array('item_sale_id' => $item_id[$i]), $data2);
							 }
						redirect(base_url($url));
					}
					else
					{
						$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Error While Adding Sales'.'</div>');
					}
			
			
			redirect(base_url('Sales'));
		}
		public function sale_view()
	{
	
		$id = $this->input->get('sale_id');
		$data['sales']= $this->Sales_model->get_by_id($id);
		//print_r($data);exit();
		$data['sales_items']= $this->Sales_model->get_by_id_from_itemwise_sale($id);
		$this->load->model('Customer_model');	
		$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('saleview',$data);
		$this->load->view('footer');
	}
	public function sale_print($id1='')
	{
		if ($id1) {
			$id=$id1;
		}
		else
		{$id = $this->input->get('sale_id');}
		
		$data['sales']= $this->Sales_model->get_by_id($id);
		//print_r($data);exit();
		$data['sales_items']= $this->Sales_model->get_by_id_from_itemwise_sale($id);
		$this->load->model('Item_Sale_Model');
		$this->load->model('Customer_model');	
		$data['items']=$this->Item_Sale_Model->get_all_item_sales();
		$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('saleprint',$data);
		
	}
	public function exportCSV(){
		// file name
		//print_r($_POST);exit();
		$from_date = $this->input->post('from_date');
		$to_date = $this->input->post('to_date');
		$filename = 'sales_'.date('Ymd').'.csv';
		$sales = $this->Sales_model->durationsales($from_date,$to_date);
		//print_r($sales);exit();
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-Type: application/csv; "); 
		
		// get data
		

		// file creation
		$file = fopen('php://output', 'w');
		$title=array("Sales");
		fputcsv($file, $title);
		$header = array("S.No","Date","Bill No.","Order No.","E-Way Bill No.","Vehicle Reg No.","Delivery At","Customer ID.","Number of Item"," Freight/Packing & forwading transportation ","Sub Total Amount","SGST Percentage","SGST Value","CGST Percentage","CGST Value","IGST Percentage","IGST Value","Grand Total");
		fputcsv($file, $header);

		foreach ($sales as $key=>$line){
		 fputcsv($file,$line);
		}

		fclose($file);
		exit;
		redirect(base_url('Sales'));
	}
	public function cancel_sales_order($id)
	{
		$this->load->model('Purchase_model');
		$this->load->model('Item_Sale_Model');
		$currentstatus=$this->Sales_model->get_status_by_id($id);
		if ($currentstatus==0) {
			$newstatus=1;
		}
		
		$data = array(
					
					'status' => $newstatus
				);
		$this->Sales_model->sales_update(array('id' => $id), $data);
		$sale_id=$this->Sales_model->get_sales_id_by_id($id);
		$data['sale_items']=$this->Sales_model->get_by_id_from_itemwise_sale($sale_id);
		
		for($i=0; $i<sizeof($data['sale_items']); $i++)
		{
			//print_r($data['sale_items'][$i]->item_quantity);exit();
			$item_current_Stock= $this->Purchase_model->get_itemstock_by_id($data['sale_items'][$i]->item_id);			
			$new_stock=$item_current_Stock+$data['sale_items'][$i]->item_quantity;
			$data2 = array('current_stock' => $new_stock);
			$update_item_id=$data['sale_items'][$i]->item_id;
			$this->Item_Sale_Model->item_sale_update(array('item_sale_id' => $update_item_id), $data2);
		}
		
		
		echo json_encode(array("status" => TRUE));
	}
public function sale_modify()
	{
		$this->load->model('Item_Sale_Model');
		
		$data['items']=$this->Item_Sale_Model->get_all_item_sales();
		$id = $this->input->get('sale_id');
		$data['sales']= $this->Sales_model->get_by_id($id);
		//print_r($data['sales']);exit();
		$data['sales_items_stock']= $this->Sales_model->get_by_id_from_itemwise_sale_stock($id);
		$data['sales_items']= $this->Sales_model->get_by_id_from_itemwise_sale($id);
		$this->load->model('Customer_model');	
		$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('salemodify',$data);
		$this->load->view('footer');
	}
	public function sales_update()
			{
				$this->load->model('Item_Sale_Model');
				$this->load->model('Purchase_model');
				//print_r( $_POST);exit();
					
					$saleid = $this->input->post('saleid');
					$id = $this->input->post('id');
					$item_id = $this->input->post('item_id');
					$hsn_no = $this->input->post('hsn_no');
					$item_name = $this->input->post('item_name');
					$item_quantity = $this->input->post('item_quantity');
					$item_price = $this->input->post('item_price');
					$item_per = $this->input->post('item_per');
					$item_cgst_percentage = $this->input->post('item_cgst_percentage');
					$item_sgst_percentage = $this->input->post('item_sgst_percentage');
					$item_igst_percentage = $this->input->post('item_igst_percentage');
					$total_amount = $this->input->post('total_amount');
					$data = array(
					'transpotation' => $this->input->post('transpotation'),
					'sub_total' => $this->input->post('item_total'),
					'sgst_percentage' => $this->input->post('sgst_percentage'),
					'sgst_value' => $this->input->post('sgst_value'),
					'cgst_percentage' => $this->input->post('cgst_percentage'),
					'cgst_value' => $this->input->post('cgst_value'),
					'igst_percentage' => $this->input->post('igst_percentage'),
					'igst_value' => $this->input->post('igst_value'),
					'sale_grand_total' => $this->input->post('sale_grand_total')
					
					);

					$this->Sales_model->sales_update(array('id' => $this->input->post('saleid')), $data);
					
						for($i=0; $i<sizeof($item_id); $i++){
							$item_current_Stock= $this->Purchase_model->get_itemstock_by_id($item_id[$i]);
							
							$sales_item_previous_stock=$this->Sales_model->get_itemstock_by_temwisesale_id($id[$i],$item_id[$i]);
							$new_item_quantity=$item_quantity[$i];

							if($sales_item_previous_stock<$new_item_quantity)
							{
								$quantity_difference=$new_item_quantity-$sales_item_previous_stock;
								$new_stock=$item_current_Stock-$quantity_difference;
								//print_r($new_stock);exit();
							}
							elseif ($sales_item_previous_stock>$new_item_quantity) {
								$new_stock=$item_current_Stock+($sales_item_previous_stock-$new_item_quantity);
							}
							else{
								$new_stock=$item_current_Stock;
							}
							//$new_stock=$item_current_Stock-$item_quantity[$i];
							$data2 = array(
							'current_stock' => $new_stock
							);
							 $this->Item_Sale_Model->item_sale_update(array('item_sale_id' => $item_id[$i]), $data2);
							$data1 = array(		
							'item_quantity' => $item_quantity[$i],
							'item_price' => $item_price[$i],
							'item_per' => $item_per[$i],
							'item_cgst_percentage' => $item_cgst_percentage[$i],
							'item_sgst_percentage' => $item_sgst_percentage[$i],
							'item_igst_percentage' => $item_igst_percentage[$i],
							'total_amount' => $total_amount[$i]
							);
							if ($insert = $this->Sales_model->sale_item_update(array('id' => $id[$i]), $data1)) {
							$this->session->set_flashdata('errorMessage','<div class="alert alert-success">Sales Updated Successfully'.'</div>');
							//$url="Sales/sale_print/".$sale_id;
							$url="Sales";
						}
						else
						{
						$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Error While Updating Sales'.'</div>');
						$url="Sales";
					}	
					
						}
						
						redirect(base_url($url));
					
			
			
			redirect(base_url('Sales'));
		}
}
