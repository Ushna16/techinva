<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {
	public function __construct() {
		parent::__construct();
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	}
	public function index()
	{
		$this->load->model('Item_Purchase_Model');
		$this->load->model('Category_Purchase_Model');
		$this->load->model('Item_Sale_Model');
		$this->load->model('Category_Sales_Model');
		$this->load->model('Vendor_model');
		$this->load->model('Gst_Model');
		$this->load->model('Unit_Model');
		$data['purchaseitems']=$this->Item_Purchase_Model->no_of_rows();
		$data['purchaseitemcategory']=$this->Category_Purchase_Model->no_of_rows();
		$data['salesitems']=$this->Item_Sale_Model->no_of_rows();
		$data['saleitemcategorys']=$this->Category_Sales_Model->no_of_rows();
		$data['vendors']=$this->Vendor_model->no_of_rows();
		$data['gst']=$this->Gst_Model->no_of_rows();
		$data['units']=$this->Unit_Model->no_of_rows();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('setting',$data);
		$this->load->view('footer');
	}
}