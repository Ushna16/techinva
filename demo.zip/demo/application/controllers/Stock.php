<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stock extends CI_Controller {
	public function _constructor(){
		parent::_constructor();
		$this->load->helper('url');
		
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}

	}
	
	public function index()
	{
		$this->load->model('Stock_model');
		$data['opening_stock_total']=$this->Stock_model->openingstock_total();
		$data['purchase_stock_total']=$this->Stock_model->purchasestock_total();
		$data['sales_stock_total']=$this->Stock_model->salesstock_total();
		$data['total_item_stock']=$this->Stock_model->total_item_stock();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('stock_list1',$data);
		$this->load->view('footer');
	}
	public function detailed_view()
	{
		$this->load->model('Stock_model');
		$this->load->model('Category_Sales_Model');
		$data['category_sales']=$this->Category_Sales_Model->get_all_category_sales();
		$data['all_items']=$this->Stock_model->get_all_items();
		$data['purchase_itemwise_total']=$this->Stock_model->purchase_itemwise_total();
		$query=$this->db->query("select item_id, SUM(item_quantity) as sales_item_wise_total from itemwise_sales where created_date=CURDATE() and sale_id in(select sale_id from sales where status=0) group by item_id  ");	
		//$result=$query->result();
		//print_r($result);exit();
		
		$data['sales_itemwise_total']=$query->result();
		//$data['sales_itemwise_total']=$this->Stock_model->sales_itemwise_total();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('itemwise_stock',$data);
		$this->load->view('footer');
	}
}