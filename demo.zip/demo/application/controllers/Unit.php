<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Unit extends CI_Controller {

	public function __construct() {
		parent::__construct();

		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
		$this->load->model('Unit_Model');
	}
	public function index()
	{
		$data['units']=$this->Unit_Model->get_all_unit();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('unit',$data);
		$this->load->view('footer');
	}
	public function unit_add()
		{
			$unitname  = $this->input->post('unitname');
			
					
		
			$this->form_validation->set_rules('unitname','Unit Name', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			echo json_encode(array("status" => TRUE));
		}
		else {
			$data = array(
					'unitname' => $this->input->post('unitname'),
					'status' => '1'
					
					
				);
				$insert = $this->Unit_Model->unit_add($data);
			
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">unit Added Successfully'.'</div>');
				echo json_encode(array("status" => TRUE));
			
		}
			
		}
		public function ajax_unitedit($id)
		{
			$data = $this->Unit_Model->get_by_id($id);
			echo json_encode($data);
		}

		public function unit_update()
	{
			$unitname  = $this->input->post('unitname');
			
					
		
			$this->form_validation->set_rules('unitname','Unit Name', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			echo json_encode(array("status" => TRUE));
		}
		else {
		$data = array(
					'unitname' => $this->input->post('unitname'),
					'status' => '1'
					
					
				);

		$this->Unit_Model->unit_update(array('unit_id' => $this->input->post('unit_id')), $data);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Unit Updated Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
	}

	public function unit_delete($id)
	{

		$this->Unit_Model->delete_by_id($id);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Unit Deleted Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
public function edit_unitstatus($id)
	{
		
		$currentstatus=$this->Unit_Model->get_status_by_id($id);
		if ($currentstatus==1) {
			$newstatus=0;
		}
		else
		{
			$newstatus=1;
		}
		$data = array(
					
					'status' => $newstatus
				);
		$this->Unit_Model->unit_update(array('unit_id' => $id), $data);
		echo json_encode(array("status" => TRUE));
	}


}
