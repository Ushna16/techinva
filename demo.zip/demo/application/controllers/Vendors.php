<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendors extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Vendor_model');
	 		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	 	}


	public function index()
	{

		$data['vendors']=$this->Vendor_model->get_all_vendors();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('vendors',$data);
		$this->load->view('footer');
	}
	public function vendor_add()
		{
			$vendor_name = $this->input->post('vendor_name');
			$vendor_contact = $this->input->post('vendor_contact');
			$vendor_address = $this->input->post('vendor_address');
				$vendor_gst = $this->input->post('vendor_gst');
					
			$this->form_validation->set_rules('vendor_name','Vendor Name', 'required');
			$this->form_validation->set_rules('vendor_contact','Vendor Contact', 'required|regex_match[/^[0-9]{10}$/]');
			$this->form_validation->set_rules('vendor_address','Vendor Address', 'required');
			$this->form_validation->set_rules('vendor_gst','Vendor GST', 'required');
			
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			echo json_encode(array("status" => TRUE));
		}
		else {
			$data = array(
					'vendor_name' => $this->input->post('vendor_name'),
					'vendor_contact' => $this->input->post('vendor_contact'),
					'vendor_address' => $this->input->post('vendor_address'),
					'vendor_gst' => $this->input->post('vendor_gst'),
					
				);
				$insert = $this->Vendor_model->vendor_add($data);
			
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Vendor Added Successfully'.'</div>');
				echo json_encode(array("status" => TRUE));
			
		}
			
		}
		public function ajax_edit($id)
		{
			$data = $this->Vendor_model->get_by_id($id);
			echo json_encode($data);
		}

		public function vendor_update()
	{
		$vendor_name = $this->input->post('vendor_name');
		$vendor_contact = $this->input->post('vendor_contact');
		$vendor_address = $this->input->post('vendor_address');
			$vendor_gst = $this->input->post('vendor_gst');
					
		$this->form_validation->set_rules('vendor_name','Vendor Name', 'required');
		$this->form_validation->set_rules('vendor_contact','Vendor Contact', 'required|regex_match[/^[0-9]{10}$/]');
		$this->form_validation->set_rules('vendor_address','Vendor Address', 'required');
		$this->form_validation->set_rules('vendor_gst','Vendor GST', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Vendors'));
		}
		else {
		$data = array(
				'vendor_name' => $this->input->post('vendor_name'),
				'vendor_contact' => $this->input->post('vendor_contact'),
				'vendor_address' => $this->input->post('vendor_address'),
					'vendor_gst' => $this->input->post('vendor_gst'),
				
			);

		$this->Vendor_model->vendor_update(array('vendor_id' => $this->input->post('vendor_id')), $data);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Vendor Updated Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
	}

	public function vendor_delete($id)
	{

		$this->Vendor_model->delete_by_id($id);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Vendor Deleted Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
public function edit_vendorstatus($id)
	{
		
		$currentstatus=$this->Vendor_model->get_status_by_id($id);
		if ($currentstatus==1) {
			$newstatus=0;
		}
		else
		{
			$newstatus=1;
		}
		$data = array(
					
					'status' => $newstatus
				);
		$this->Vendor_model->vendor_update(array('vendor_id' => $id), $data);
		echo json_encode(array("status" => TRUE));
	}


}