<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_Sales_Model extends CI_Model
{

	var $table = 'salescategory';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


public function get_all_category_sales()
{
$this->db->from('salescategory');
$this->db->order_by('category_sales_id','DESC');
$query=$this->db->get();
return $query->result();
}


	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('category_sales_id',$id);
		$query = $this->db->get();
		return $query->row();
	}

	public function category_sale_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function category_sale_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('category_sales_id', $id);
		$this->db->delete($this->table);
	}
public function no_of_rows()
	{
		$this->db->select('count(*)');
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['count(*)'];
	}

}
