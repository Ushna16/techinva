<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item_Sale_Model extends CI_Model
{

	var $table = 'saleitems';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


public function get_all_item_sales()
{
$this->db->from('saleitems');
$this->db->order_by('item_sale_id','DESC');
$query=$this->db->get();
return $query->result();
}


	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('item_sale_id',$id);
		$query = $this->db->get();
		return $query->row();
	}

	public function item_sale_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function item_sale_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('item_sale_id', $id);
		$this->db->delete($this->table);
	}
public function no_of_rows()
	{
		$this->db->select('count(*)');
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['count(*)'];
	}

}
