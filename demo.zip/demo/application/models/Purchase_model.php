<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase_model extends CI_Model
{

	var $table = 'purchases';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


public function get_all_purchase()
{
$this->db->from('purchases');
$this->db->order_by('id','DESC');
$query=$this->db->get();
return $query->result();
}


	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('purchase_id',$id);
		$query = $this->db->get();

		return $query->result();
	}
	public function get_itemstock_by_id($id)
	{
		$this->db->select('current_stock','current_stock');
		$this->db->where('item_sale_id', $id);
		$query  = $this->db->get('saleitems');
		return $query->row()->current_stock;
	}

	public function purchase_item_add($data)
	{
		$this->db->insert('itemwise_purchases', $data);
		return $this->db->insert_id();
	}
	public function purchase_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}
	public function no_of_rows()
	{
		$this->db->select('count(*)');
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['count(*)'];
	}
	public function get_purchase_id($id) {     
         $this->db->select('purchase_id','purchase_id');
		$this->db->where('id', $id);
		$query  = $this->db->get($this->table);
		return $query->row()->purchase_id;
	}
	public function get_max_id() {     
         $this->db->select_max('id','id');
		$result = $this->db->get($this->table);  
		return $result->row()->id;
	}
	public function venderwise_purchase(){
		 $this->db->select('purchase_vendor, SUM(purchase_grand_total) as total, COUNT(purchase_vendor) as each_vendor_purchase');
 		$this->db->group_by('purchase_vendor'); 
 			$query = $this->db->get($this->table); 
			return $query->result();
	}
	public function get_purchase_by_vendor_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('purchase_vendor',$id);
		$this->db->order_by('id','DESC');
		$query = $this->db->get();

		return $query->result();
	}
	public function get_by_id_from_itemwise_purchase($id)
	{
		$this->db->from('itemwise_purchases');
		$this->db->where('purchase_id',$id);
		$query = $this->db->get();

		return $query->result();
	}
	public function no_of_rows_total()
	{
		$this->db->select( 'SUM(purchase_grand_total) as total','total');
		$result = $this->db->get($this->table);  
		return $result->row()->total;
	}
	function durationpurchase($from_date,$to_date){
		 $response = array();
    	
    	$this->db->from($this->table);
    	$this->db->where('purchase_date >=',$from_date);
    	$this->db->where('purchase_date <=',$to_date);
    	$query=$this->db->get();
		$response = $query->result_array();   
        return $response;
    }
}
