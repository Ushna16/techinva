<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_model extends CI_Model
{

	var $table = 'sales';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


public function get_all_sale()
{
$this->db->from('sales');
$this->db->order_by('id','DESC');
$query=$this->db->get();
return $query->result();
}
public function get_month_sale()
{
$this->db->where('MONTH(sale_date)',date('m'));
$this->db->from('sales');
$this->db->order_by('id','DESC');
$query=$this->db->get();
return $query->result();
}
	public function no_of_rows_month()
	{
		$this->db->select('count(*)');		
		$this->db->where('MONTH(sale_date)',date('m'));
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['count(*)'];
	}
		public function month_sales_amount()
	{
		$this->db->select('SUM(sale_grand_total)');		
		$this->db->where('MONTH(sale_date)',date('m'));
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['SUM(sale_grand_total)'];
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('sale_id',$id);
		$query = $this->db->get();

		return $query->result();
	}

	public function sale_item_add($data)
	{
		$this->db->insert('itemwise_sales', $data);
		return $this->db->insert_id();
	}
	public function sale_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}
	public function no_of_rows()
	{
		$this->db->select('count(*)');
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['count(*)'];
	}
	public function total_sales_amount()
	{
		$this->db->select('SUM(sale_grand_total)');
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['SUM(sale_grand_total)'];
	}
	public function get_sale_id($id) {     
         $this->db->select('sale_id','sale_id');
		$this->db->where('id', $id);
		$query  = $this->db->get($this->table);
		return $query->row()->sale_id;
	}
	public function get_max_id() {     
         $this->db->select_max('id','id');
		$result = $this->db->get($this->table);  
		return $result->row()->id;
	}

	public function get_sale_by_vendor_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('sale_vendor',$id);
		$this->db->order_by('id','DESC');
		$query = $this->db->get();

		return $query->result();
	}
	public function get_by_id_from_itemwise_sale($id)
	{
		$this->db->from('itemwise_sales');
		$this->db->where('sale_id',$id);
		$query = $this->db->get();

		return $query->result();
	}
		public function customerwise_sales(){
		 $this->db->select('customer_id, SUM(sale_grand_total) as total, COUNT(customer_id) as each_customer_sales');
 		$this->db->group_by('customer_id'); 
 		$this->db->order_by('customer_id','DESC');
 			$query = $this->db->get($this->table); 
			return $query->result();
	}
		public function get_sales_by_customer_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('customer_id',$id);
		$this->db->order_by('id','DESC');
		$query = $this->db->get();

		return $query->result();
	}
	function durationsales($from_date,$to_date){
		 $response = array();
    	
    	$this->db->from($this->table);
    	$this->db->where('sale_date >=',$from_date);
    	$this->db->where('sale_date <=',$to_date);
    	$query=$this->db->get();
		$response = $query->result_array();   
        return $response;
    }
    public function sales_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}
	public function sale_item_update($where, $data)
	{
		$this->db->update('itemwise_sales', $data, $where);
		return $this->db->affected_rows();
	}
	public function get_status_by_id($id)
	{
		 $this->db->select('status','status');
		$this->db->where('id', $id);
		$query  = $this->db->get($this->table);
		return $query->row()->status;
	}
	public function get_itemstock_by_temwisesale_id($id,$item_id)
	{
		 $this->db->select('item_quantity','item_quantity');
		$this->db->where('id', $id);
		$this->db->where('item_id', $item_id);
		$query  = $this->db->get('itemwise_sales');
		return $query->row()->item_quantity;
	}
	public function get_sales_id_by_id($id)
	{
		 $this->db->select('sale_id','sale_id');
		$this->db->where('id', $id);
		$query  = $this->db->get($this->table);
		return $query->row()->sale_id;
	}
		public function get_by_id_from_itemwise_sale_stock($id)
	{
		$this->db->select('item_id, SUM(item_quantity) as sales_item_wise_total_stock');
		$this->db->where('sale_id',$id);
 		$this->db->group_by('item_id'); 
 		$query = $this->db->get('itemwise_sales'); 
		return $query->result();
	}
}
