<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stock_model extends CI_Model
{

	var $table = 'saleitems';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function openingstock_total()
	{
		$this->db->select( 'SUM(opening_stock) as opening_stock','opening_stock');
		$result = $this->db->get($this->table);  
		return $result->row()->opening_stock;
	}
	public function purchasestock_total()
	{
		$this->db->select( 'SUM(item_quantity) as purchase_stock','purchase_stock');
		$this->db->where('created_date',date("Y-m-d"));
		$result = $this->db->get('itemwise_purchases');  
		return $result->row()->purchase_stock;
	}
	public function salesstock_total()
	{
		$this->db->select( 'SUM(item_quantity) as sales_stock','sales_stock');
		$this->db->where('created_date',date("Y-m-d"));
		$result = $this->db->get('itemwise_sales');  
		return $result->row()->sales_stock;
	}
	public function total_item_stock()
	{
		$this->db->select( 'SUM(current_stock) as total_item_stock','total_item_stock');
		$result = $this->db->get('saleitems');  
		return $result->row()->total_item_stock;
	}
	public function get_all_items()
	{
		$this->db->from('saleitems');
		$this->db->order_by('item_sale_id','DESC');
		$query=$this->db->get();
		return $query->result();
	}
	public function purchase_itemwise_total()
	{
		$this->db->select('item_id, SUM(item_quantity) as purchase_item_wise_total');
		$this->db->where('created_date',date("Y-m-d"));
 		$this->db->group_by('item_id'); 
 		$query = $this->db->get('itemwise_purchases'); 
		return $query->result();
	}
	public function sales_itemwise_total()
	{
		$this->db->select('item_id, SUM(item_quantity) as sales_item_wise_total');
		$this->db->where('created_date',date("Y-m-d"));
 		$this->db->group_by('item_id'); 
 		$query = $this->db->get('itemwise_sales'); 
		return $query->result();
	}
}
