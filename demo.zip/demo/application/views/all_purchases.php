<style>
  input{
    font-size: 0.8rem !important;
    padding: 0.4rem 0.75rem !important;
  }
</style>
<div class="content-wrapper">
          <div class="row">
          
           <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <div class="row">
                       <div class="col-lg-3">
                            <a href="<?php echo base_url(); ?>Purchase/purchase_now" class="btn btn-success">Add Purchase/Prod.</a>
                              
                            </div>
                            <div class="col-lg-7">
                              <form role="form" action="<?php echo base_url(); ?>Purchase/exportCSV" method="post">
                      <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;"> From &nbsp;&nbsp; </label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                            <input type="date" class="form-control" value="<?php echo date('Y-m-d',  strtotime('-1 month'));?>" name="from_date"/>
                          </div>
                        </div>
                      </div>
                   <div class="col-lg-4">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label" style="padding-right: 0px !important;">To&nbsp;&nbsp;</label>
                          <div class="col-sm-10" style="padding-left: 0px !important;">
                            <input type="date" class="form-control" value="<?php echo date("Y-m-d");?>" name="to_date"/>
                          </div>
                        </div>
                      </div>
            
            
            <div class="col-md-3">
               
               <button type="submit" class="btn btn-primary">Export</button>
            </div>
            </div>
             </form>
                            </div>
                             <div class="col-lg-2">
                            
                              <a href="<?php echo base_url(); ?>Purchase" class="btn btn-warning">Vendor-wise</a>
                            </div>
                          </div>
                              
                  <div class="table-responsive">
                 
                    <table bgcolor="#e7e2b0" class="table table-bordered table-striped"  id="table_for_pagination">
                      <thead>
                        <tr bgcolor="#f4cdb3">
                         <!-- <th>
                            S.No
                          </th>-->
                          <th>
                           <center>Bill No</center>
                          </th>
                         <th>
                        <center>   Date</center>
                         </th>
                         
                         <th>
                          <center> Vendor Name</center>
                         </th>
                          
                         
                          <th>
                            <center>Bill Amount</center>
                          </th>
                          <th>
                            <center>Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php  $i=sizeof($all_purchases); foreach($all_purchases as $vendor_purchases_list){?>
                        <tr>
                           <!--<td><?php echo $i--;;?></td>-->
                           <td><center><?php echo $vendor_purchases_list->purchase_id;?></center></td>
                           <td><center>
                            <?php echo date('d-m-Y', strtotime($vendor_purchases_list->purchase_date));?></center></td>
                            
                            <td><center>
                              <?php foreach($vendors as $vendor){
                                if ($vendor->vendor_id==$vendor_purchases_list->purchase_vendor) {
                                  echo $vendor->vendor_name; break ;}} 
                              ?></center>
                              </td>
                          
                            <td><center><?php echo round($vendor_purchases_list->purchase_grand_total);?></center></td>
                          <td><center>
                             <a href="<?php echo base_url() ?>Purchase/purchase_view?purchase_id=<?php echo $vendor_purchases_list->purchase_id;?>" class="btn btn-primary">View
                             </a>
                            <a href="<?php echo base_url() ?>Purchase/purchase_print?purchase_id=<?php echo $vendor_purchases_list->purchase_id;?>" class="btn btn-success" target="_blank">
                              Print</a></center>
                          </td>
                        </tr>
                      <?php }?>
                     
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>