<div class="content-wrapper">
          <div class="row">
            <!-- <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                  <a href="<?php echo base_url(); ?>Customers/adding" class="btn btn-success">Add new customer</a>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                     <a href="<?php echo base_url(); ?>Customers/adding" class="btn btn-success">Add new customer</a>
                     <br></br>
                  <!--<center><h4 class="card-title">Customers</h4></center>-->
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped"  id="table_for_pagination">
                      <thead>
                        <tr>
                        
                            <th>
                             <center>Customer ID</center>
                          </th>
                         <th>
                             <center>Name</center>
                          </th>
                        
                          
                          <th><center>
                            Mobile No</center>
                          </th>
                          <th><center>
                            Bills</center>
                          </th>
                          
                          <th>
                           <center> Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php foreach($customers as $customer){?>
                        <tr>
                         
                        
                           
                               <td><center><?php echo $customer->customer_id;?></center></td>
                            <td><center><?php echo $customer->customer_name;?></center></td>
                          
                         
                          <td><center><?php echo $customer->customer_contact;?></center></td>
                         <td><center>
                              <?php $i=sizeof($customer_sales); foreach($customer_sales as $customer_sale){
                            
                              if ($customer->customer_id==$customer_sale->customer_id) { ?>
                              <?php echo $customer_sale->each_customer_sales;?>
                               <?php }  }?></center></td>
                         
                          <td><center>
                            <a href="<?php echo base_url() ?>Customers/view_customer?customer_id=<?php echo $customer->customer_id;?>"  class="btn btn-primary">
                                    View</a>
                                    <a href="<?php echo base_url() ?>Customers/edit_customer?customer_id=<?php echo $customer->customer_id;?>"  class="btn btn-success" >
                                   Edit</a>
                                    <a href="<?php echo base_url() ?>Customers/purchase_customer?customer_id=<?php echo $customer->customer_id;?>"  class="btn btn-warning" >
                                    Bills</a></center>
                          </td>
                          
                        </tr>
                          <?php }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>
        