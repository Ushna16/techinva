 <footer class="footer">
          <div class="container-fluid clearfix">
            <center><span class=" d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.techkshetrainfo.com/" target="_blank">Techkshetra Info solutions pvt.ltd</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Billing ERP 
            </span></center>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="<?php echo base_url(); ?>assets/vendors/js/vendor.bundle.base.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url(); ?>assets/js/off-canvas.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url(); ?>assets/js/dashboard.js"></script>
  <!-- End custom js for this page-->
  <!-- Tale filter pagination and search js for this page-->
    <script src="<?php echo base_url() ?>assets/jquery-3.3.1.js.js"></script>
     <script src="<?php echo base_url() ?>assets/jquery.dataTables.min.js"></script>
      <script src="<?php echo base_url() ?>assets/dataTables.bootstrap.min.js"></script>
      <script>
         $(document).ready( function () {
      $('#table_for_pagination').DataTable();
  } );
      </script>
</body>

</html>