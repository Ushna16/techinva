<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Techinva</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/iconfonts/font-awesome/css/font-awesome.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/logo.png" />
   <!-- for search and filter -->
   <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/bootstrap.min.css" />
   <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/dataTables.bootstrap.min.css" />
   <style>
       .table th{
    padding: 15px 8px;
    vertical-align: top;
    border-top: 1px solid #f2f2f2; }
 
  .table td {
    padding: 8px 8px;
   
    border-top: 1px solid #f2f2f2; }
    label, #table_for_pagination_info{
        font-size:13px;
    }
    #table_for_pagination_length label select{
        line-height:15px;
         font-size:13px;
        height:27px;
    }
   </style>
</head>

