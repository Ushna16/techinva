<div class="content-wrapper">
          <div class="row">
          	 <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                	 <button type="submit" onclick="add_item()" class="btn btn-success">Add New Item</button>
                </div>
              </div>
            </div>
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <center><h4 class="card-title">Purchase Items</h4></center>
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>
                            S.No
                          </th>
                          
                          <th>
                             Item Code
                          </th>
                          <th>
                             Name
                          </th>
                          <th>
                             Purchase Price
                          </th>
                           <th>
                             Item GST
                          </th>
                          <th width="150px">
                            Action
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                         <?php $i=sizeof($item_purchases); foreach($item_purchases as $item_purchase){?>

                     <tr>
                        <td><?php echo $i--;;?></td>
                         <td><?php echo $item_purchase->item_purchase_id;?></td>
                          <td><?php echo $item_purchase->pitemname;?></td>
                         <td><?php echo $item_purchase->pprice;?></td>
                         <td><?php echo $item_purchase->pitemgst;?></td>
                                 
                                <td>
                                      <button class="btn btn-warning" onclick="edit_item(<?php echo $item_purchase->item_purchase_id;?>)">Edit</button>
                                    <!--<button class="btn btn-danger" onclick="delete_item(<?php echo $item_purchase->item_purchase_id;?>)"><i class="fa fa-remove"></i></button>-->

                                </td>
                      </tr>
                     <?php }?>
                       
                       
                      
                       
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>
        <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;


    function add_item()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_item(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('index.php/Item_Purchase/ajax_item_purchaseedit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="item_purchase_id"]').val(data.item_purchase_id);
            $('[name="created_date"]').val(data.created_date);
            $('[name="pitemname"]').val(data.pitemname);
            $('[name="pitemdes"]').val(data.pitemdes);
             $('[name="pprice"]').val(data.pprice);
             $('[name="pitemgst"]').val(data.pitemgst);
              $('[name="category"]').val(data.category);


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Purchase Item'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('index.php/Item_Purchase/item_purchase_add')?>";
      }
      else
      {
        url = "<?php echo site_url('index.php/Item_Purchase/item_purchase_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                //alert('Error adding / update data(' + errorThrown+')');
                location.reload();
            }
        });
    }

    function delete_item(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/Item_Purchase/item_purchase_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

      }
    }

  </script>

<!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        
        <h3 class="modal-title">Add item</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="item_purchase_id"/>
          <input type="date" name="created_date" value="<?php echo date("Y-m-d");?>" hidden />
          <div class="form-body">
              <div class="form-group">
                <label class="control-label col-md-3">Category<span style="color: red">*</span></label>

                <div class="col-md-12">
                   
                    <select name="category" class="form-control">
                      <option value="">Select</option>
                      <?php foreach($category_purchases as $category_purchase){?>
                      <option value="<?php echo $category_purchase->category_purchase_id;?>"><?php echo $category_purchase->pcategory;?></option>
                        <?php }?>
                    </select>
                    <!--<input name="category" placeholder="Category" class="form-control" type="text">-->
                
                </div>
            </div>

          </div>
            <div class="form-group">
              <label class="control-label col-md-3">Item Name<span style="color: red">*</span></label>
              <div class="col-md-12">
                <input name="pitemname" placeholder="Item Name" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Description<span style="color: red"></span></label>
              <div class="col-md-12">
                <textarea name="pitemdes"  cols="30" rows="10" placeholder="Item Description" class="form-control"></textarea>
               
              </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Item Price<span style="color: red">*</span></label>
                <div class="col-md-12">
                    <input name="pprice" placeholder="Item Price" class="form-control" type="text" pattern="[0-9]+">

                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Item GST(%)<span style="color: red">*</span></label>
                <div class="col-md-12">
                    <input name="pitemgst" placeholder="Item GST" class="form-control" type="text" pattern="[0-9]+">

                </div>
            </div>
            
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->