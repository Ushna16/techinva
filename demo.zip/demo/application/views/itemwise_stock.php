<div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <button class="btn btn-warning" onclick="exportTableToExcel('table_for_pagination', 'Item_Stock')" style="float: right;">Export</button>
                  <h4 class="card-title"><center>Itemwise Stock List ( <?php echo date('d-m-Y');?> )</center>
                
                  </h4>
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped"  id="table_for_pagination">
                      <thead>
                        <tr>
                         
                           <th>
                          <center>Item Code</center>
                          </th>
                          <th>
                          <center>Item Category</center>
                          </th>
                          <th>
                          <center>Item Name</center>
                          </th>
                         
                          <!--th>
                            Opening Stock
                          </th-->
                           <th>
                            <center>Purchase</center>
                          </th>
                          <!--th>
                            Total Stock
                          </th-->
                          <th>
                            <center>Sales</center>
                          </th>
                           <th>
                            <center>Current Stock</center>
                          </th>
                         
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i=sizeof($all_items); foreach($all_items as $item_sale){?>
                        <tr>
                          <td><center><?php echo $item_sale->item_id;?></center></td>
                           <td><center><?php foreach($category_sales as $category_sale){if($item_sale->category==$category_sale->category_sales_id) {echo $category_sale->scategory; }}?></center></td>
                          <td><center><?php echo $item_sale->sitemname;?></center></td>
                          <!--td><center><?php echo $item_sale->opening_stock;?><center></td-->
                          <td><center>
                            <?php foreach($purchase_itemwise_total as $purchase_item){
                            if ($item_sale->item_sale_id==$purchase_item->item_id) {echo $purchase_item->purchase_item_wise_total;}}?>
                           </center>
                         </td>
                         <!--td><center>
                            <?php foreach($purchase_itemwise_total as $purchase_item){
                            if ($item_sale->item_sale_id==$purchase_item->item_id) {echo $purchase_item->purchase_item_wise_total+$item_sale->opening_stock;}}?>  
                            </center>
                          </td-->
                          <td><center>
                           <?php foreach($sales_itemwise_total as $sale_item){
                            if ($item_sale->item_sale_id==$sale_item->item_id) {echo $sale_item->sales_item_wise_total;}}?>
                            </center>
                          </td>
                           <td><center><?php echo $item_sale->current_stock;?></center></td>  
                        </tr>
                      
                      <?php }?>
                     
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>
        <script>
      function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}
        </script>