<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Billing ERP</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="<?php echo base_url()?>assets/css/print.css" rel="stylesheet" />
    <!-- GOOGLE FONTS -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css' />

</head>
<body onload="window.print(); window.close();">


   <?php foreach($purchases as $purchase) {
                       $purchase_id=$purchase->purchase_id;
                       $purchase_date=$purchase->purchase_date;
                       $purchase_vendor=$purchase->purchase_vendor;
                       $purchase_reference=$purchase->purchase_reference;
                       
                       $sub_total=$purchase->sub_total;
                    $sgst_percentage=$purchase->sgst_percentage;
                    $sgst_value=$purchase->sgst_value;
                   $cgst_percentage=$purchase->cgst_percentage;
                    $cgst_value=$purchase->cgst_value;
                      $igst_percentage=$purchase->igst_percentage;
                    $igst_value=$purchase->igst_value;
                    
                       $purchase_grand_total=$purchase->purchase_grand_total;
                       $purchase_upload=$purchase->purchase_upload;
                    } ?>
 <div class="container">
     
      <div class="row pad-top-botm ">
         
          <div class="col-lg-12 col-md-12 col-sm-12">
            
               <Center><strong>Techkshetra Info Solutions Pvt. Ltd</strong></Center>
             
         </div>
     </div>
     <div  class="row text-center contact-info">
         <div class="col-lg-12 col-md-12 col-sm-12">
             <hr />
             <span>
                 <strong>Purchase No : </strong> <?php echo $purchase_id;?>
             </span>
             <span>
                 <strong>Vendor : </strong><?php foreach($vendors as $vendor){ if ($vendor->vendor_id==$purchase_vendor) {
                     echo $vendor->vendor_name; }}?>
             </span>
              <span>
                 <strong>Ref No : </strong>  <?php echo $purchase_reference;?>
             </span>
             <hr />
         </div>
     </div>
     <div  class="row pad-top-botm client-info">
          <div class="col-lg-12 col-md-12 col-sm-12">
            
               <h4>  <strong>Payment Details </strong></h4>
            <b>Grand Total Amount : <?php echo $purchase_grand_total;?> /-</b>
              <br />
               Bill Date :  <?php echo date('Y-m-d H:i:s');?>
              <br />
               <b>Payment Status :  Paid </b>
               <br />
               Delivery Date :  <?php echo $purchase_date;?>
              <br />
               Purchase Date :  <?php echo $purchase_date;?>
         </div>
     </div>
     <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12">
           <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th><center>S.no</center></th>

                              <th><center>Code</center></th>
                               <th><center>Hsn No.</center></th>
                               <th><center> Name</center></th>
                              
                              <th><center>Quantity</center></th>
                              <th><center>Per   Cost</center></th>
                              <th><center>Per Unit</center></th>
                              <th><center>Total Amount</center></th>
                                </tr>
                            </thead>
                            <tbody>

                            
                               <?php $i=1; foreach($purchases_items as $purchase){?>
                                <tr>
                                    <td> <?php  echo $i++; ?></td>
                                    <td><?php echo $purchase->item_id;?></td>
                                    <td><?php echo $purchase->hsn_no;?></td>
                                    <td><?php echo $purchase->item_name;?></td>
                                 <td><?php echo $purchase->item_quantity;?></td>
                                    <td><?php echo $purchase->item_price;?></td>
                                    <td><?php echo $purchase->item_per;?></td>
                                    <td><?php echo $purchase->total_amount;?></td>
                                </tr>
                                <?php }?>
                               
                            </tbody>
                        </table>
               </div>
 <br>
   <div  class="row text-center contact-info">
         <div class="col-lg-12 col-md-12 col-sm-12">
            
            
             <span>
                 <strong>SGST : </strong><?php echo $sgst_value;?> /-
             </span>
              <span>
                 <strong>CGST : </strong> <?php echo $cgst_value;?> /-
             </span>
             <span>
                 <strong>IGST : </strong><?php echo $igst_value;?> /-  
             </span>
              <span>
                 <strong>Sub Total : </strong> <?php echo $sub_total;?> /-
             </span>
             <br>
             <hr />
         </div>
     </div>
        <br>     
  <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="ttl-amts">
                  <h4> <strong>Grand Total Amount :<?php echo $purchase_grand_total;?> /-</strong> </h4>
             </div>
         </div>
     </div>
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12">
            <strong> Important: </strong>
             <ol>
                  <li>
                    This is an electronic generated invoice so doesn't require any signature.

                 </li>
                 <li>
                     Please read all terms and polices on  www.yourdomaon.com for returns, replacement and other issues.

                 </li>
             </ol>
             </div>
         </div>
      
 </div>

</body>
</html>
