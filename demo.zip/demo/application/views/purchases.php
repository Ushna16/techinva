<div class="content-wrapper">
          <div class="row">
           <!--<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                  <a href="<?php echo base_url(); ?>Purchase/purchase_now" class="btn btn-success">Add Purchase/Prod.</a>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                     <a href="<?php echo base_url(); ?>Purchase/purchase_now" class="btn btn-primary">Add Purchase/Prod.</a>
                     &nbsp;&nbsp;&nbsp;
                  
                     <a href="<?php echo base_url(); ?>Purchase/all_purchase" class="btn btn-warning" style="float:right">All purchase</a>
                  
                     <br></br>
                  <!--<center><h4 class="card-title">Purchase/Prod. List</h4></center>-->
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped"  id="table_for_pagination">
                      <thead>
                        <tr  bgcolor="#f4cdb3">
                          <!--<th>
                            S.No
                          </th>
                         -->
                          <th>
                          <center> Vendor Name</center>
                          </th>
                          <th>
                           <center>Total Purchase</center>
                          </th>
                          <th>
                            <center>Amount</center>
                          </th>
                          <th>
                            <center>Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php  $i=1; foreach($vendor_purchases as $vendor_purchase){?>
                        <tr>
                          <!-- <td><?php echo $i++;;?></td>-->
                            <?php foreach($vendors as $vendor){
                              if ($vendor->vendor_id==$vendor_purchase->purchase_vendor) { ?>
                                <td><center><?php echo $vendor->vendor_name;?></center></td>
                               <?php }  }?>
                            <td><center><?php echo $vendor_purchase->each_vendor_purchase;?></center></td>
                            <td><center><?php echo round($vendor_purchase->total);?></center></td>
                          <td><center>
                             <a href="<?php echo base_url() ?>Purchase/purchase_vendordetailed?vendors_id=<?php echo $vendor_purchase->purchase_vendor;?>" class="btn btn-primary">
                                    View</a></center>
                                    <!--<a href="<?php echo base_url() ?>Eachview/purchase_print?purchase_id=<?php echo "";?>" class="btn btn-success" target="_blank">
                                    <i class="fa fa-print"></i></a>-->
                          </td>
                        </tr>
                      <?php }?>
                     
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>