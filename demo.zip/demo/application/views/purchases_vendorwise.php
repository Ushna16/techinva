<div class="content-wrapper">
          <div class="row">
          
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                 
                  <h4 class="card-title">Vendor: <b><?php  $i=1; foreach($vendor_purchases_lists as $vendor_purchases_list){
                    foreach($vendors as $vendor){
                    if ($vendor->vendor_id==$vendor_purchases_list->purchase_vendor) {
                     echo $vendor->vendor_name; break 2;}}}?></b>
                     <br></br>
                     <!--<center>Purchase List</center>-->
                   </h4>
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped"  id="table_for_pagination">
                      <thead>
                        <tr  bgcolor="#f4cdb3">
                          <!--<th>
                           <center> S.No</center>
                          </th>-->
                         <th>
                          <center> Date</center>
                         </th>
                          <th>
                          <center> Purchase Id</center>
                          </th>
                         
                          <th>
                           <center> Amount</center>
                          </th>
                          <th>
                            <center>Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php  $i=sizeof($vendor_purchases_lists); foreach($vendor_purchases_lists as $vendor_purchases_list){?>
                        <tr>
                          <!-- <td><center><?php echo $i--;;?></center></td>-->
                           <td><center>
                            <?php echo date('d-m-Y', strtotime($vendor_purchases_list->purchase_date));?></center></td>
                          <td><center><?php echo $vendor_purchases_list->purchase_id;?></center></td>
                            <td><center><?php echo round($vendor_purchases_list->purchase_grand_total);?></center></td>
                          <td><center>
                             <a href="<?php echo base_url() ?>Purchase/purchase_view?purchase_id=<?php echo $vendor_purchases_list->purchase_id;?>" class="btn btn-info">
                              View</a>
                            <a href="<?php echo base_url() ?>Purchase/purchase_print?purchase_id=<?php echo $vendor_purchases_list->purchase_id;?>" class="btn btn-success" target="_blank">
                              Print</a></center>
                          </td>
                        </tr>
                      <?php }?>
                     
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>