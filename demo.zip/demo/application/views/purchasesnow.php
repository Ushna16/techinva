<style>
 .table td {

    padding: 18px 8px;

}
 .table th {

    padding: 18px 18px;

}
.hidding, .hidding input{
  display: none !important;
  width: 0%;
}
</style>
<div class="content-wrapper">
          <div class="row">
           
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <center><h4 class="card-title">Add New Purchase</h4></center>
                  <form class="form-sample" action="<?php echo base_url() ?>Purchase/purchase_add" enctype="multipart/form-data" method="post">
                    <p class="card-description">

                    </p>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;"> &nbsp; &nbsp; Date</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                             <input type="date" value="<?php echo date("Y-m-d");?>" class="form-control" name="purchase_date" placeholder="Purchase Date">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;"> &nbsp; &nbsp; ID</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="purchase_id" placeholder="Purchase Id" value="<?php echo $purchase_id;?>" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">Vendor<span style="color: red"></span></label>
                          <div class="col-sm-8" style="padding-left: 0px !important;">
                            <select class="form-control m-bot15" name="purchase_vendor" required="required">
                              
                                        <?php foreach($vendors as $vendor){?>
                                        <option value="<?php echo $vendor->vendor_id;?>"><?php echo $vendor->vendor_name;?></option>
                                        <?php }?>
                                    </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">Reference</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                           <input type="text" class="form-control" name="purchase_reference" placeholder="Reference">
                          </div>
                        </div>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                          <thead>
                            <tr>
            
                              <th></th>
                              <th>Code <span style="color: red">*</span></th>
                                <th><center> &nbsp; &nbsp; &nbsp;Hsn No.</center></th>
                               <th><center> &nbsp; &nbsp; &nbsp; Name</center></th>
                              
                              <th><center> &nbsp; &nbsp;Quantity<span style="color: red">*</span></center></th>
                              <th><center> &nbsp; &nbsp;Per Cost</center></th>
                               <th><center>Per Unit</center></th>
                              <th><center>Total Amount</center></th>
                            </tr>
                          </thead>
                        </table>
                        </div>
                        <table class="table table-striped b-t b-light" id="dataTable" >
                              <tbody>
                               <tr>
                                <td><INPUT type="checkbox" name="chk"/></td>
                                <td width="13%">
                                <select class="form-control m-bot15" name="item_id[]" id="purchase_item" onchange="itemwisedetails(this)" required="required">
                                  <option value="">Select</option>
                                    <?php foreach($items as $item){?>
                                    <option value="<?php echo $item->item_sale_id;?>"  ><?php echo $item->item_id;?></option>
                                    <?php }?>
                                </select>
                                </td>
                                 <td><input type="text" class="form-control" name="hsn_no[]" id="hsn_no"  readonly></td>
                                <td><input type="text" class="form-control" name="item_name[]" id="item_name" required="required" readonly></td>
                                
                                <td><input type="text" class="form-control" name="item_quantity[]" id="purchase_quantity" placeholder="Quantity" onkeyup="multiplyRow()" onchange="multiplyRow()" step="any" required pattern="[0-9]{1,10}" ></td>
                                <td><input type="text" class="form-control" name="item_price[]" id="purchase_price" required="required"  onkeyup="multiplyRow()" step="any"  pattern="[0-9]+(\.[0-9]{0,2})?"></td>
                                  <td><input type="text" class="form-control" name="item_per[]" id="item_per"></td>
                                <td><input type="text" class="form-control" name="total_amount[]" id="total_amount" placeholder="Total Amount" readonly onchange="grandtotal()" pattern="[0-9]{1,10}"></td>
                                <td class="hidding" style="width: 0%;padding: 0px;"><input type="text"  name="item_cgst_percentage[]" id="item_cgst_percentage" placeholder="CGST" readonly pattern="[0-9]{1,10}" style="display: none;"></td>
                                <td class="hidding" style="width:0%;padding: 0px"><input type="text"  name="item_cgst_value[]" id="item_cgst_value" placeholder="CGST" readonly pattern="[0-9]{1,10}" style="display: none;"></td>
                                 <td class="hidding" style="width: 0%;padding: 0px;"><input type="text"  name="item_sgst_percentage[]" id="item_sgst_percentage" placeholder="SGST" readonly pattern="[0-9]{1,10}" style="display: none;"></td>
                                  <td class="hidding" style="width: 0%;padding: 0px;"><input type="text"  name="item_sgst_value[]" id="item_sgst_value" placeholder="SGST" readonly pattern="[0-9]{1,10}" style="display: none;"></td>
                                   <td class="hidding" style="width: 0%;padding: 0px;"><input type="text"  name="item_igst_percentage[]" id="item_igst_percentage" placeholder="IGST" readonly pattern="[0-9]{1,10}" style="display: none;"></td>
                                  <td class="hidding" style="width: 0%;padding: 0px;"><input type="text"  name="item_igst_value[]" id="item_igst_value" placeholder="IGST" readonly pattern="[0-9]{1,10}" style="display: none;"></td>
                               
                              </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    
                <hr>  <div class="row">
                      <div class="col-md-2">
                        <INPUT type="button" value="Add Item" onclick="addRow('dataTable')" class="btn btn-primary addmore"/>
                      </div>
                      <div class="col-md-2">
                       <INPUT type="button" value="Delete Item" onclick="deleteRow('dataTable')" class="btn btn-warning addmore"/>
                      </div>
                   <div class="col-md-5">
                        
                        </div>
                     <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label"   style="padding-right: 0px !important;">Sub_Total :</label>
                          <div class="col-sm-8"  style="padding-left: 0px !important;">
                           <input type="text" class="form-control" id="item_total" name="item_total" readonly="readonly">
                          </div>
                          </div>
                        </div>
                    </div>
                
                      <hr>
                            <div class="row">
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"  style="padding-right: 0px !important;">&nbsp;&nbsp;&nbsp;&nbsp;SGST</label>
                          <div class="col-sm-9"  style="padding-left: 0px !important;">
                            <input type="text" class="form-control" id="sgst_percentage" name="sgst_percentage" placeholder="SGST" pattern="[0-9]{1-20}" value="" hidden>
                             <input type="text" class="form-control" id="sgst_value" name="sgst_value" placeholder="GST" pattern="[0-9]{1-20}" readonly >
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"  style="padding-right: 0px !important;">&nbsp;&nbsp;CGST</label>
                          <div class="col-sm-9"  style="padding-left: 0px !important;">
                            <input type="text" class="form-control" id="cgst_percentage" name="cgst_percentage" placeholder="CGST" pattern="[0-9]{1-20}" value="" hidden>
                             <input type="text" class="form-control" id="cgst_value" name="cgst_value" placeholder="CGST" pattern="[0-9]{1-20}" readonly >
                        </div>
                      </div>
                    </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"  style="padding-right: 0px !important;">&nbsp;&nbsp;&nbsp;&nbsp;IGST</label>
                          <div class="col-sm-9"  style="padding-left: 0px !important;">
                            <input type="text" class="form-control" id="igst_percentage" name="igst_percentage" placeholder="IGST" pattern="[0-9]{1-20}" value="" hidden>
                             <input type="text" class="form-control" id="igst_value" name="igst_value" placeholder="GST" pattern="[0-9]{1-20}" readonly >
                          </div>
                        </div>
                      </div>
                      
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label"  style="padding-right: 0px !important;">&nbsp;&nbsp;Grand Total</label>
                          <div class="col-sm-7"  style="padding-left: 0px !important;">
                            <input type="text" class="form-control" id="sale_grand_total" placeholder="Grand Total" readonly name="sale_grand_total" pattern="[0-9]{1-20}">
                          </div>
                        </div>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-md-9">
                        <div class="form-group row">
                          <label class="col-sm-7 col-form-label">Upload<span style="color: red"> (pdf,doc,jpeg,jpg,png files of maxsize 2Mb)</span></label>
                          
                            <div class="col-lg-6">
                                    <input type="file" name="userfile" id="purchase_upload">
                                </div>
                         
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                         <center><br>
                          <input type="submit"  name="submit" value="Submit" class="btn btn-success"/> &nbsp; &nbsp;
                          <input type="reset"  name="submit" value="Clear" class="btn btn-danger"/>
                        </center>
                      </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        <SCRIPT language="javascript">
   

        function addRow(tableID) {

            var table = document.getElementById(tableID);

            var rowCount = table.rows.length;
            var row = table.insertRow(rowCount);

            var colCount = table.rows[0].cells.length;

            for(var i=0; i<colCount; i++) {

                var newcell = row.insertCell(i);

                newcell.innerHTML = table.rows[0].cells[i].innerHTML;
                //alert(newcell.childNodes);
                switch(newcell.childNodes[0].type) {
                    case "text":
                            newcell.childNodes[0].value = "";
                            break;
                    case "checkbox":
                            newcell.childNodes[0].checked = false;
                            break;
                    case "select-one":
                            newcell.childNodes[0].selectedIndex = 0;
                            break;
                }
            }
        }
        function deleteRow(tableID) {
            try {
            var table = document.getElementById(tableID);
            var rowCount = table.rows.length;
            var purchase_grand_total = document.getElementById('purchase_grand_total');
            var totalchecked=0;
            for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var chkbox = row.cells[0].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                  totalchecked++;
                }
              }
              if (totalchecked) {
                for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var chkbox = row.cells[0].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                    if(rowCount <= 1) {
                        alert("Cannot delete all the rows.");
                        break;
                    }
                    table.deleteRow(i);
                    sale_grand_total.value-=row.cells[6].childNodes[0].value;
                     multiplyRow();
                    rowCount--;
                    i--;
                }
            }
              }
             else{
              alert("Please select the item to delete.");
              
             }
           /*for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var chkbox = row.cells[0].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                    if(rowCount <= 1) {
                        alert("Cannot delete all the rows.");
                        break;
                    }
                    table.deleteRow(i);
                    purchase_grand_total.value-=row.cells[6].childNodes[0].value;
                    grandtotal();
                    discount_cal();
                    rowCount--;
                    i--;
                }
            }*/
            }catch(e) {
                alert(e);
            }
        }
             
       function itemwisedetails(value_seleted) {
               
            try {
              
            var table = document.getElementById('dataTable');
            var rowCount = table.rows.length;
            var sale_grand_total = document.getElementById('sale_grand_total');
             var cgst_item_value = document.getElementById('cgst_value');
            var sgst_item_value = document.getElementById('sgst_value');
            var igst_item_value = document.getElementById('igst_value');
            var discount = document.getElementById('discount');

            for(var i=0; i<rowCount; i++) {

                var row = table.rows[i];
               
                <?php foreach($items as $item){?>
                  $item_sale_id=<?php echo $item->item_sale_id; ?>;
                  
                    if (value_seleted.value==$item_sale_id && row.cells[1].childNodes[1].value==$item_sale_id) {
                      
                       //alert($pitemdes);
                      row.cells[3].childNodes[0].value="<?php echo $item->sitemname; ?>";
                       row.cells[2].childNodes[0].value="<?php echo $item->hsn_no; ?>";
                      row.cells[5].childNodes[0].value="<?php echo $item->pprice;?>";
                     row.cells[6].childNodes[0].value="<?php echo $item->sper;?>";
                     row.cells[8].childNodes[0].value="<?php echo $item->cgst;?>";
                     row.cells[10].childNodes[0].value="<?php echo $item->sgst;?>";
                     row.cells[12].childNodes[0].value="<?php echo $item->igst;?>";
                    }               
                <?php }?>
                var qty = row.cells[4].childNodes[0].value;
                var price = row.cells[5].childNodes[0].value;
              
                var qty_price=qty*price;
              
                row.cells[7].childNodes[0].value=qty_price;
               
                 var total_amount = row.cells[7].childNodes[0].value;
                var cgst_percentage = row.cells[8].childNodes[0].value;
                row.cells[9].childNodes[0].value=(total_amount*cgst_percentage)/100;
                var cgst_item_value = row.cells[9].childNodes[0].value;
                var sgst_percentage = row.cells[10].childNodes[0].value;
                row.cells[11].childNodes[0].value=(total_amount*sgst_percentage)/100;
                var sgst_item_value = row.cells[11].childNodes[0].value;
                var igst_percentage = (row.cells[12].childNodes[0].value)*1;
                row.cells[13].childNodes[0].value=(total_amount*igst_percentage)/100;
                var igst_item_value = row.cells[13].childNodes[0].value;
                if(i==0)
                {
                    sale_grand_total.value = total_amount*1;
                    cgst_value.value = cgst_item_value*1;
                    sgst_value.value = sgst_item_value*1;
                    igst_value.value = igst_item_value*1;
                }
                else{
             sale_grand_total.value = (sale_grand_total.value*1)+ (total_amount*1);
              cgst_value.value =((cgst_value.value*1)+(cgst_item_value*1)).toFixed(3);
             sgst_value.value =((sgst_value.value*1)+(sgst_item_value*1)).toFixed(3);
             igst_value.value =((igst_value.value*1)+(igst_item_value*1)).toFixed(3);
              }
                
            }
            document.getElementById('item_total').value=sale_grand_total.value;

          
          sale_grand_total.value= document.getElementById('item_total').value;
         
        sale_grand_total.value=(cgst_value.value*1)+(sgst_value.value*1)+(igst_value.value*1)+(sale_grand_total.value*1);
            }catch(e) {
                alert(e);
            }
        }
        function multiplyRow() {
            try {

            var table = document.getElementById('dataTable');
            var rowCount = table.rows.length;
            var sale_grand_total = document.getElementById('sale_grand_total');
            var discount = document.getElementById('discount');
            var cgst_item_value = document.getElementById('cgst_value');
            var sgst_item_value = document.getElementById('sgst_value');
            var igst_item_value = document.getElementById('igst_value');
             var transpotation = document.getElementById('transpotation');

            for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var qty = row.cells[4].childNodes[0].value;
                var price = row.cells[5].childNodes[0].value;
                var qty_price=qty*price;
                row.cells[7].childNodes[0].value=qty_price.toFixed(2);
               
                var total_amount = row.cells[7].childNodes[0].value;
                var cgst_percentage = row.cells[8].childNodes[0].value;
                row.cells[9].childNodes[0].value=(total_amount*cgst_percentage)/100;
                var cgst_item_value = row.cells[9].childNodes[0].value;
                var sgst_percentage = row.cells[10].childNodes[0].value;
                row.cells[11].childNodes[0].value=(total_amount*sgst_percentage)/100;
                var sgst_item_value = row.cells[11].childNodes[0].value;
                var igst_percentage = row.cells[12].childNodes[0].value;
                row.cells[13].childNodes[0].value=(total_amount*igst_percentage)/100;
                var igst_item_value = row.cells[13].childNodes[0].value;
                if(i==0)
                {
                    sale_grand_total.value = total_amount*1;
                    cgst_value.value =cgst_item_value*1;
                    sgst_value.value =sgst_item_value*1;
                    igst_value.value =igst_item_value*1;
                }
                else{
             sale_grand_total.value = (sale_grand_total.value*1)+ (total_amount*1);
             cgst_value.value =((cgst_value.value*1)+(cgst_item_value*1)).toFixed(3);
             sgst_value.value =((sgst_value.value*1)+(sgst_item_value*1)).toFixed(3);
             igst_value.value =((igst_value.value*1)+(igst_item_value*1)).toFixed(3);
              }
                
            }
             document.getElementById('item_total').value=sale_grand_total.value;

         
          sale_grand_total.value= document.getElementById('item_total').value;
         
        sale_grand_total.value=Math.round((cgst_value.value*1)+(sgst_value.value*1)+(igst_value.value*1)+(sale_grand_total.value*1));
            }catch(e) {
                alert(e);
            }
        }

        
        function grandtotal() {
            try {
            var table = document.getElementById('dataTable');
            var rowCount = table.rows.length;
            var sale_grand_total = document.getElementById('sale_grand_total');
            var sale_grand_total = document.getElementById('sale_grand_total');
            for(var i=0; i<rowCount; i++) {
                
                var row = table.rows[i];

                var total_amount = row.cells[7].childNodes[0].value;
                if(i==0)
                {
                    sale_grand_total.value = total_amount*1;
                }
                else{
             sale_grand_total.value = (sale_grand_total.value*1)+ (total_amount*1);
              }
            }
            document.getElementById('item_total').value=sale_grand_total.value;
            }catch(e) {
                alert(e);
            }
        }
        function discount_cal() {
            try {
            var discount = document.getElementById('discount');
            var sale_grand_total = document.getElementById('sale_grand_total');
            /*if(discount.value != 0){
              grandtotal();
                var discount_value=(purchase_grand_total.value  * discount.value)/100;
                purchase_grand_total.value=Math.round(purchase_grand_total.value-discount_value);
            }*/
             grandtotal();
             
                var discount_value=(sale_grand_total.value  * discount.value)/100;
                sale_grand_total.value=sale_grand_total.value-discount_value;
                gst_cal();
            }
            catch(e) {
                alert(e);
            }
        }
        function gst_cal() {
            try {
            var sgst = document.getElementById('sgst_percentage');
            var sgst_value_variable = document.getElementById('sgst_value');
             var cgst = document.getElementById('cgst_percentage');
            var cgst_value_variable = document.getElementById('cgst_value');
            var igst = document.getElementById('igst_percentage');
            var igst_value_variable = document.getElementById('igst_value');
            var sale_grand_total = document.getElementById('sale_grand_total');
         
                var sgst_value=(sale_grand_total.value* sgst.value)/100;
                var cgst_value=(sale_grand_total.value* cgst.value)/100;
                var igst_value=(sale_grand_total.value* igst.value)/100;
                //alert(gst_value);
                sgst_value_variable.value=sgst_value.toFixed(2);
                 cgst_value_variable.value=cgst_value.toFixed(2);
                
                 igst_value_variable.value=igst_value.toFixed(2);
            
                sale_grand_total.value=Math.round((sale_grand_total.value*1)+sgst_value+cgst_value+igst_value);
            
            }
            catch(e) {
                alert(e);
            }
        }

        var delay = 0;
var offset = 250;

document.addEventListener('invalid', function(e){
   $(e.target).addClass("invalid");
   $('html, body').animate({scrollTop: $($(".invalid")[0]).offset().top - offset }, delay);
}, true);
document.addEventListener('change', function(e){
   $(e.target).removeClass("invalid")
}, true);
    </SCRIPT>