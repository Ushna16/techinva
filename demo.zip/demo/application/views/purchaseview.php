<style>
table td, table th{
  padding: 18px 10px !important;
}
</style>
<div class="content-wrapper">
          <div class="row">
           <?php foreach($purchases as $purchase) {
                       $purchase_id=$purchase->purchase_id;
                       $purchase_date=$purchase->purchase_date;
                       $purchase_vendor=$purchase->purchase_vendor;
                       $purchase_reference=$purchase->purchase_reference;
                       
                       $sub_total=$purchase->sub_total;
                    $sgst_percentage=$purchase->sgst_percentage;
                    $sgst_value=$purchase->sgst_value;
                   $cgst_percentage=$purchase->cgst_percentage;
                    $cgst_value=$purchase->cgst_value;
                      $igst_percentage=$purchase->igst_percentage;
                    $igst_value=$purchase->igst_value;
                    
                       $purchase_grand_total=$purchase->purchase_grand_total;
                       $purchase_upload=$purchase->purchase_upload;
                    } ?>
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <center><h4 class="card-title">Purchase Details</h4></center>
                  <form class="form-sample">
                    <p class="card-description">

                    </p>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group row" >
                          <label class="col-sm-3 col-form-label">Date</label>
                          <div class="col-sm-9">
                             <input type="date" value="<?php echo $purchase_date;?>" class="form-control" name="purchase_date" placeholder="Purchase Date" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="purchase_id" placeholder="Purchase Id" value="<?php echo $purchase_id;?>" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Vendor</label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control" name="purchase_vendor" value="<?php foreach($vendors as $vendor){ if ($vendor->vendor_id==$purchase_vendor) {
                     echo $vendor->vendor_name; }}?>" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Reference</label>
                          <div class="col-sm-8">
                           <input type="text" class="form-control" name="purchase_reference" placeholder="Reference" value="<?php echo $purchase_reference;?>" readonly>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                          <thead>
                           <tr>
                               <th><center>S.no</center></th>

                              <th><center>Code</center></th>
                               <th><center>Hsn No.</center></th>
                               <th><center> Name</center></th>
                              
                              <th><center>Quantity</center></th>
                              <th><center>Per   Cost</center></th>
                              <th><center>Per Unit</center></th>
                              <th><center>Total Amount</center></th>
                            </tr>
                          </thead>
                        
                            <tbody>
                               <?php $i=1; foreach($purchases_items as $purchase){?>
                             <tr>
                                <td><?php echo $i++;;?></td>
                                <td>
                                  <input type="text" class="form-control"  readonly name="item_id" value="<?php echo $purchase->item_id;?>">
                                </td>
                                <td>
                                  <input type="text" class="form-control" readonly name="hsn_no" value="<?php echo $purchase->hsn_no;?>">
                                </td>
                                <td> <input type="text" class="form-control"  readonly name="item_name" value="<?php echo $purchase->item_name;?>"></td>
                                
                                <td><input type="text" class="form-control" readonly name="item_quanity" value="<?php echo $purchase->item_quantity;?>"></td>
                                <td><input type="text" class="form-control" readonly name="item_price" value="<?php echo $purchase->item_price;?>"></td>
                                <td><input type="text" class="form-control" readonly name="item_per" value="<?php echo $purchase->item_per;?>"></td>
                                
                                 <td><input type="text" class="form-control" id="amount" placeholder="Total Amount" value="<?php echo $purchase->total_amount;?>" readonly></td>
                              </tr>
                                <?php } ?>
                          </tbody>
                        </table>
                      </div>
                    </div>

               </div>
             
                 <hr>
                    <div class="row">
                      
                    <div class="col-md-8">
                        <div class="form-group row">
                          <?php if ($purchase_upload) {  ?>

                          <label class="col-sm-3 col-form-label">Upload</label>
                          
                            <div class="col-sm-9">
                                   <a href="<?php echo base_url('uploads/purchase/' . $purchase_upload); ?>" download class="btn btn-info">View/Download</a>
                                </div>
                           <?php } ?>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label" style="padding-right: 0px !important;">Subtotal Amount</label>
                          <div class="col-sm-7" style="padding-left: 0px !important;">
                           <input type="text" class="form-control" id="item_total" name="item_total" readonly="readonly" value="<?php echo $sub_total;?>">
                          </div>
                        </div>
                      </div>
                
                     
                    </div><hr>

                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">SGST</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                            
                             <input type="text" class="form-control" id="sgst_value" name="sgst_value"  value="<?php echo $sgst_value;?>" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">CGST </label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                          
                             <input type="text" class="form-control" id="cgst_value" name="cgst_value" placeholder="CGST" pattern="[0-9]{1-20}" readonly   value="<?php echo $cgst_value;?>">
                        </div>
                      </div>
                    </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">IGST</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                             <input type="text" class="form-control" id="igst_value" name="igst_value"   value="<?php echo $igst_value;?>" readonly >
                          </div>
                        </div>
                      </div>
                      
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label" style="padding-right: 0px !important;">Grand Total</label>
                          <div class="col-sm-7" style="padding-left: 0px !important;">
                            <input type="text" class="form-control"  placeholder="Grand Total" readonly name="sale_grand_total"   value="<?php echo $purchase_grand_total;?>">
                          </div>
                        </div>
                      </div>
                    </div><hr>
                  <div class="row">
                      
                    <div class="col-md-12">
                        <div class="form-group row"  style="float: right;">
                        <a href="<?php $url='purchase_print/'.$purchase_id; echo $url; ?>"  class="btn btn-warning" target="_blank">Print</a>
                            <!--<button type="submit" class="btn btn-warning">Print View</button>-->
                        </div>
                      </div>
                    
                
                      
                    </div>
                 
                
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

       