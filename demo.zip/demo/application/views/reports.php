 
<!--main content start-->
<section id="main-content">

	<section class="wrapper">
		<div class="table-agile-info">
  <div class="panel panel-default">
    
    <div class="row w3-res-tb">
      <div class="col-sm-1">
        <div class="input-group">
        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From: </label>
        </div>
      </div>
      <div class="col-sm-2">
        <div class="input-group">
       <input type="date" class="input-sm form-control" value="<?php echo date("Y-m-d");?>">
        </div>
      </div>
      <div class="col-sm-1">
        <div class="input-group">
        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To: </label>
        </div>
      </div>
      <div class="col-sm-2">
        <div class="input-group">
        <input type="date" class="input-sm form-control" value="<?php echo date("Y-m-d");?>">
        </div>
      </div>
      <div class="col-sm-1">
        <div class="input-group">
        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Status: </label>
        </div>
      </div>
      <div class="col-sm-2 ">
        <select class="input-sm form-control w-sm inline v-middle">
          <option value="0">Returned</option>
          <option value="1">Pending</option>
         
        </select>              
      </div>
     <div class="col-sm-1">
        <div class="input-group">
        <label>&nbsp;&nbsp;&nbsp;&nbsp;Balance: </label>
        </div>
      </div>
      <div class="col-sm-2 ">
        <select class="input-sm form-control w-sm inline v-middle">
          <option value="0">Cleared</option>
          <option value="1">Pending</option>
         
        </select>              
      </div>
      </div>
<hr>
       <div class="row w3-res-tb">
         <label for="amount" class="col-lg-3 col-sm-3 control-label" style="text-align: right;"> Sales Type:</label>
     
      <div class="col-sm-2" >
        <select class="input-sm form-control w-sm inline v-middle">
          <option value="0">Route</option>
          <option value="1">Direct</option>
        </select>             
      </div>
       <div class="col-sm-1">
        
      </div>
    
                        <label class="form-group col-sm-2 control-label col-lg-2" style="text-align: right;">Sales Route Id :</label>
                        <div class="col-lg-2">
                            <select class="form-group form-control m-bot15" >
                                <option>SI258</option>
                                <option>SI987</option>
                                <option>SI876</option>
                                <option>SI435</option>
                                <option>SI654</option>
                                <option>SI258</option>
                                <option>SI987</option>
                                <option>SI876</option>
                                <option>SI435</option>
                                <option>SI654</option>
                                <option>SI258</option>
                                <option>SI987</option>
                                <option>SI876</option>
                                <option>SI435</option>
                                <option>SI654</option>
                            </select>

                           
                        </div>
                 
      <div class="col-sm-1">
        
      </div>
      
    </div>
<hr>
     <div class="row w3-res-tb">
     <label for="amount" class="col-lg-3 col-sm-3 control-label" style="text-align: right;">Customer Id:</label>
      <div class="col-sm-2">
        <div class="input-group">
          <input type="text" name="customerid" class="input-sm form-control">
        </div>
      </div>
      <div class="col-sm-2">
        
      </div>
      <div class="col-sm-2">
        <div class="input-group">
          <button type="submit" class="btn btn-success">Generate Report</button>&nbsp;
        </div>
      </div>
     </div>
     <div class="panel-heading">
      Report
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            
            <th>S.No</th>
            <th>Date</th>
            <th>Route Id</th>
            <th>User Id</th>
            <th>Customer</th>
            <th>Sales</th>
             <th>Balance</th>
          </tr>
        </thead>
        <tbody>
          <tr>
           
            <td>1</td>
            <td>22-09-2017</td>
           
            <td><span class="text-ellipsis">1234567896</span></td>
            <td>SI234</td>
             <td><span class="text-ellipsis">Customer 1</span></td>
            <td>12</td>
            <td>500</td>
           
          </tr>
          <tr>
           
            <td>2</td>
            <td>22-09-2017</td>
           
            <td>3214569874</td>
            <td>SI234</td>
             <td>Customer 2</td>
            <td>10</td>
             <td>700</td>
            
          </tr>
          <tr>
           
            <td>3</td>
            <td>22-09-2017</td>
            <td>3214569874</td>
            <td>SI234</td>
            <td>Customer 3</td>
            <td>8</td>
             <td>800</td>
            
          </tr>
         <tr>
           
            <td>4</td>
            <td>22-09-2017</td>
            <td>5814569874</td>
            <td>SI254</td>
            <td>Customer 4</td>
            <td>2</td>
             <td>1500</td>
           
          </tr>
         <tr>
           
            <td>5</td>
            <td>22-09-2017</td>
            <td>1235478965</td>
            <td>SI234</td>
            <td>Customer 5</td>
            <td>6</td>
             <td>700</td>
           
          </tr>
          <tr>
           
            <td>6</td>
            <td>22-09-2017</td> 
            <td>5214569874</td>
            <td>SI239</td>
            <td>Customer 6</td>
            <td>12</td>
             <td>1600</td>
            
          </tr>
          <tr>
           
            <td>7</td>
            <td>22-09-2017</td>
            <td>3214564874</td>
            <td>SI274</td>
            <td>Customer 7</td>
            <td>100</td>
             <td>5000</td>
            
          </tr>
         <tr>
           
            <td>8</td>
            <td>22-09-2017</td> 
            <td>2145655874</td>
            <td>SI734</td>
            <td>Customer 8</td>
            <td>2</td>
             <td>0</td>
            
          </tr>
        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      <div class="row">
        
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
        </div>
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
            <li><a href="">1</a></li>
            <li><a href="">2</a></li>
            <li><a href="">3</a></li>
            <li><a href="">4</a></li>
            <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>
</section>
 <!-- footer -->