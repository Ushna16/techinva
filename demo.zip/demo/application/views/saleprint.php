<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Techinva</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="<?php echo base_url()?>assets/css/print.css" rel="stylesheet" />
    <!-- GOOGLE FONTS -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css' />

</head>
<body onload="window.print(); window.close();">
  <img src="<?php echo base_url()?>assets/images/bill.jpg" alt="jpg" width="100%" heigh="100%">

<!--<body onload="window.print(); window.close();">-->

  <?php foreach($sales as $sale) {
                       $sale_id=$sale->sale_id;
                       $sale_date=$sale->sale_date;
                        $order_no=$sale->order_no;
                        $eway_no=$sale->eway_no;
                          $vehicle_reg_no=$sale->vehicle_reg_no;
                       $customer_id=$sale->customer_id;
                       $transpotation=$sale->transpotation;
                       $sub_total=$sale->sub_total;
                    $sgst_percentage=$sale->sgst_percentage;
                    $sgst_value=$sale->sgst_value;
                   $cgst_percentage=$sale->cgst_percentage;
                    $cgst_value=$sale->cgst_value;
                      $igst_percentage=$sale->igst_percentage;
                    $igst_value=$sale->igst_value;
                       $sale_grand_total=$sale->sale_grand_total;
                    } ?>


    <span style="position: absolute;top: 13%;left:81%;color: #000;font-size: 21.5px"> <?php echo $sale_id;?></span>

     <span style="position: absolute;top: 14.5%;left:14%;color: #000;font-size: 21.5px"> 
      <?php foreach($customers as $customer){ if ($customer->customer_id==$customer_id) {
                     echo $customer->customer_name; }}?> 
    </span>
    <span style="position: absolute;top: 17.6%;left:0.9%;color: #000;font-size: 21.5px;font-weight: 500">  Delivery at</span>
    <span style="position: absolute;top: 17.5%;left:14%;color: #000;font-size: 21.5px">  <?php echo $sale->site;?></span>
    <span style="position: absolute;top: 16.7%;left:81%;color: #000;font-size: 21.5px">  <?php echo date('d-m-Y', strtotime($sale->sale_date));?></span>
    <span style="position: absolute;top: 19.6%;left:83%;color: #000;font-size: 21.5px">  <?php echo $sale->order_no;?></span>
     <span style="position: absolute;top: 23.2%;left:86%;color: #000;font-size: 21.5px">  <?php echo $sale->eway_no;?></span>

     <span style="position: absolute;top: 20.8%;left:14.5%;color: #000;font-size: 21.5px"> 
    <?php foreach($customers as $customer){ if ($customer->customer_id==$customer_id) {
                     echo $customer->customer_gst; }}?>
    </span>
     <span style="position: absolute;top: 24.2%;left:14%;color: #000;font-size: 21.5px">  <?php echo $sale->vehicle_reg_no;?></span>
    <?php $i=1;$top=30.5; foreach($sales_items as $sale){?>
                                
        <span style="position: absolute;top:<?php  echo $top;?>%;left:3%;color: #000;font-size: 20px"> <?php  echo $i++; ?></span>
         <span style="position: absolute;top:<?php  echo $top;?>%;left:8%;color: #000;font-size: 20px"><?php echo $sale->item_name;?></span>
        
         <span style="position: absolute;top:<?php  echo $top+1.7;?>%;left:8%;color: #000;font-size: 20px">
             
 <?php foreach($items as $item){ if ($item->item_sale_id==$sale->item_id) {
                     echo substr($item->sitemdes, 0, 50); }}?>
    </span> 
          <span style="position: absolute;top:<?php  echo $top;?>%;left:54%;color: #000;font-size: 20px"><?php echo $sale->hsn_no;?></span>
        <span style="position: absolute;top:<?php  echo $top;?>%;left:68%;color: #000;font-size: 20px"><?php echo $sale->item_quantity;?></span>
          <span style="position: absolute;top:<?php  echo $top;?>%;left:72%;color: #000;font-size: 20px"><?php echo $sale->item_price;?></span>
           <span style="position: absolute;top:<?php  echo $top;?>%;left:78.1%;color: #000;font-size: 18px"><?php echo $sale->item_per;?></span>
          <span style="position: absolute;top:<?php  echo $top;?>%;right:8%;color: #000;font-size: 20px"><?php $number=explode('.',$sale->total_amount);echo $number[0];?></span>
       <span style="position: absolute;top:<?php  echo $top;?>%;left:96.3%;color: #000;font-size: 20px"><?php $number=explode('.',$sale->total_amount);
       if (sizeof($number)>1) {  echo $number[1]; }
       else {echo "00";}?> </span>
    <?php $top=$top+3.5;}?>
    <span style="position: absolute;bottom:38%;right:8%;color: #000;font-size: 20px"><?php $number=explode('.',$transpotation);echo $number[0];?></span>
    <span style="position: absolute;bottom:38%;left:96.3%;color: #000;font-size: 20px"><?php $number=explode('.',$transpotation);
       if (sizeof($number)>1) {  echo $number[1]; }
       else {echo "00";}?>      
    </span>
     <span style="position: absolute;bottom:34.4%;right:8%;color: #000;font-size: 20px"><?php $number=explode('.',$sub_total);echo $number[0];?></span>
      <span style="position: absolute;bottom:34.4%;left:96.3%;color: #000;font-size: 20px"><?php $number=explode('.',$sub_total);
       if (sizeof($number)>1) {  echo $number[1]; }
        else {echo "00";}?>    
      </span>
     <!--<span style="position: absolute;bottom:37%;right:25%;color: #000;font-size: 20px"><?php echo $cgst_percentage;?></span>-->
       <span style="position: absolute;bottom:31.7%;right:8%;color: #000;font-size: 20px"><?php $number=explode('.',$sgst_value);echo $number[0];?></span>
       <span style="position: absolute;bottom:31.7%;left:96.3%;color: #000;font-size: 20px"><?php $number=explode('.',$sgst_value);
       if (sizeof($number)>1) {  echo $number[1]; }
         else {echo "00";}?>
           
         </span>
     <!--<span style="position: absolute;bottom:35%;right:25%;color: #000;font-size: 20px"><?php echo $cgst_percentage;?></span>-->
     
     <span style="position: absolute;bottom:29.2%;right:8%;color: #000;font-size: 20px"><?php $number=explode('.',$cgst_value);echo $number[0];?></span>
     <span style="position: absolute;bottom:29.2%;left:96.3%;color: #000;font-size: 20px"><?php $number=explode('.',$cgst_value);
       if (sizeof($number)>1) {  echo $number[1]; }
         else {echo "00";}?>
      </span>
    
        <!--<span style="position: absolute;bottom:32.5%;right:25%;color: #000;font-size: 20px"><?php echo $igst_percentage;?></span>-->
     <span style="position: absolute;bottom:26.7%;right:8%;color: #000;font-size: 20px"><?php $number=explode('.',$igst_value);
     echo $number[0];?></span>
      <span style="position: absolute;bottom:26.7%;left:96.3%;color: #000;font-size: 20px"> <?php $number=explode('.',$igst_value);
       if (sizeof($number)>1) {  echo $number[1]; }
         else {echo "00";}?></span>
   
       <span style="position: absolute;bottom:24%;right:8%;color: #000;font-size: 20px"><b><?php $number=explode('.',$sale_grand_total);echo $number[0];?></b></span>
       <span style="position: absolute;bottom:24%;left:96.3%;color: #000;font-size: 20px"><b>
        <?php $number=explode('.',$sale_grand_total);
       if (sizeof($number)>1) {  echo $number[1]; }
         else {echo "00";}?></b>
       </span>
       <span style="position: absolute;bottom:26%;left:30%;color: #000;font-size: 19px">
        <?php 
  $number=$sale_grand_total;
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'One', 2 => 'Two',
        3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six',
        7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
        10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve',
        13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',
        16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
        19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',
        40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty',
        70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety');
    $digits = array('', 'Hundred','Thousand','Lakh', 'Crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' & ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
   $message=explode(' ', ($Rupees ? $Rupees . 'Rupees ' : '') . $paise."", 3);
   echo $message[0]." ".$message[1]." ";
  
?>
  
</span>
<span style="position: absolute;bottom:24%;left:2%;color: #000;font-size: 19px">
        <?php 
  $number=$sale_grand_total;
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'One', 2 => 'Two',
        3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six',
        7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
        10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve',
        13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',
        16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
        19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',
        40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty',
        70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety');
    $digits = array('', 'Hundred','Thousand','Lakh', 'Crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' & ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
   $message=explode(' ', ($Rupees ? $Rupees . 'Rupees ' : '') . $paise."");
   for ($i=2; $i <sizeof( $message); $i++) { 
     echo $message[$i]." ";
   }
  
?>
  
</span>
 <!--<div class="container">

             <div class="text-right contact-info">
              <span> Discount :  <b><?php echo $discount;?> </b>% </span>
             <span> GST (<b><?php echo $gst_percentage;?></b>%) : <?php echo $gst_value;?> </span>
             
             </div>
             <hr />
            
 
              <div class="ttl-amts">
                  <h4> <strong>Grand Total Amount :<?php echo $sale_grand_total;?></strong> </h4>
             </div>
         </div>
     </div>
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12">
            <strong> Important: </strong>
             <ol>
                  <li>
                    This is an electronic generated invoice so doesn't require any signature.

                 </li>
                 <li>
                     Please read all terms and polices on  www.yourdomaon.com for returns, replacement and other issues.

                 </li>
             </ol>
             </div>
         </div>
      
 </div>-->

</body>
</html>