<style>
  input{
    font-size: 0.8rem !important;
    padding: 0.5rem 0.75rem !important;
  }
</style>
<div class="content-wrapper">
          <div class="row">
             <!--<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <?php echo $this->session->flashdata('errorMessage') ?>
                  <?php echo $this->session->flashdata('successMessage')?>
                  <a href="<?php echo base_url(); ?>Sales/addsales" class="btn btn-success">Add New Sale</a>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div class="row">
                       <div class="col-lg-3">
                    <a href="<?php echo base_url(); ?>Sales/addsales" class="btn btn-success">Add New Sale</a>
                    
                   </div>
                   <div class="col-lg-7">
                     <form role="form" action="<?php echo base_url(); ?>Sales/exportCSV" method="post">
                      <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">  From </label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                            <input type="date" class="form-control" value="<?php echo date('Y-m-d',  strtotime('-1 month'));?>" name="from_date"/>
                          </div>
                        </div>
                      </div>
                   <div class="col-lg-4">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label" style="padding-right: 0px !important;">To</label>
                          <div class="col-sm-10" style="padding-left: 0px !important;">
                            <input type="date" class="form-control" value="<?php echo date("Y-m-d");?>" name="to_date"/>
                          </div>
                        </div>
                      </div>
            
            
            <div class="col-md-3">
               
               <button type="submit" class="btn btn-primary">Export</button>
            </div>
            </div>
             </form>
           </div>
           <div class="col-lg-2">
                   <a href="<?php echo base_url(); ?>Customers/customerlist" class="btn btn-warning">Customer-Wise</a>
                   </div>
             </div>
                 
               <!-- <center><h4 class="card-title">Sales</h4></center>-->
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped"  id="table_for_pagination">
                      <thead>
                        <tr bgcolor="#aabcbf">
                          <!--<th>
                            S.No
                          </th>-->
                          <th><center>
                            Date</center>
                          </th>
                          
                          
                          <th><center>
                            Customer Name</center>
                          </th>
                          <th><center>
                            Bill No</center>
                          </th>
                          <th><center>
                            Amount</center>
                          </th>
                          <th><center>
                            Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php  $i=sizeof($sales); foreach($sales as $sale){?>
                        <tr>
                         <!--<td><?php echo $i--;?></td>-->
                          <td><center>
                            <?php echo date('d-m-Y', strtotime($sale->sale_date));?></center></td>
                         
                         <!-- <td><center>
                          <!-- <?php echo $sale->customer_id;?>-->
                          <!--</center>
                          </td>-->
                         <td><center>
                         <?php foreach($customers as $customer){ if ($customer->customer_id==$sale->customer_id) {
                     echo $customer->customer_name; }}?></center>
                          </td>
                           <td><center>
                           <?php echo $sale->sale_id;?></center>
                          </td>
                          <td><center>
                             <?php echo $sale->sale_grand_total;?></center>
                          </td>
                          <td>
                             <a href="<?php echo base_url() ?>Sales/sale_view?sale_id=<?php echo $sale->sale_id;?>" class="btn btn-primary">
                             View</a>
                            <a href="<?php echo base_url() ?>Sales/sale_print?sale_id=<?php echo $sale->sale_id;?>" class="btn btn-success" target="_blank">
                              Print</a>
                            
                              <button  class="btn btn-danger" 
                              <?php if($sale->status=="1"){echo "disabled";}
                                else{?> 
                                onclick="cancel_sales(<?php echo $sale->id;?>)" 
                                 <?php }?>
                                 >
                                 <?php if($sale->status=="0"){echo "&nbsp;&nbsp;&nbsp;&nbsp;Cancel&nbsp;&nbsp;&nbsp;";}else{echo "Cancelled";}?>
                             </button>
                              <?php if($sale->status=="0"){ ?>
                              <a href="<?php echo base_url() ?>Sales/sale_modify?sale_id=<?php echo $sale->sale_id;?>" class="btn btn-warning" target="_blank">
                              Modify</a> <?php }?>
                            
                          </td>
                        </tr>
                      <?php }?>
                      </tbody>
                    </table>
                  </div>

                </div>
              </div>
            </div>
            
           
          </div>
        </div>
    <script type="text/javascript">

function cancel_sales(id)
    {
      if(confirm('Are you sure want to update the status'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/Sales/cancel_sales_order')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Cannot update the unit Status');
            }
        });

      }
    }
  </script>