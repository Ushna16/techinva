<!--enquiry--->
<script type="text/javascript" src="<?php echo base_url();?>/js/basic.js"></script>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
 <style>
 .table td {

    padding: 18px 8px;

}
 .table th {

    padding: 18px 18px;

}
.hidding, .hidding input{
  display: none !important;
  width: 0%;
}
</style>
 <!-- <style>

  
  .filtersug{
  padding:5px;
  background:#ffffff;
  border-bottom:1px solid #dddddd;
  cursor:pointer;
  }
  .filtersugs{
  z-index:1000;
  margin-top:5px;
  padding:5px;
  background:#ffffff;
  position:absolute;
  border:1px solid #dddddd;
  }
  .filtered{
  background:#FFFF99;
  color:#212121;
  padding:5px;
  margin-right:2px;
  }
  .dropdown-menu-form {
    padding: 5px 10px 0;
    max-height: 100px;
    overflow-y: scroll;
}
  
  </style>-->
 
 <div class="content-wrapper">
          <div class="row">
          	    <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">


<div class="row">
                      
<div class="col-md-2">
    <div class="form-group row">
<label>From Date</label>
<div class="col-sm-18" style="padding-left:0px !important;">
<input type="text"   id="datepicker1"  name="to_datee" value="<?php echo date('d-m-Y',time());?>"  class="form-control" style="width:70%;">
</div>
</div>
</div>

                      
<div class="col-md-2">
    <div class="form-group row">
<label>To Date</label>
<div class="col-sm-18" style="padding-left:0px !important;">
<input type="text"   id="datepicker1"  name="to_datee" value="<?php echo date('d-m-Y',time());?>"  class="form-control" style="width:70%;">
</div>
</div>
</div>
<div class="col-md-2">
    <div class="form-group row">
                          <label>customer</span></label>
                          <div class="col-sm-9" style="padding-left:0px !important;">
                          
                            <select class="form-control m-bot15" name="purchase_vendor" required="required">
                              <option value="">Select</option>
                                        <?php foreach($vendors as $vendor){?>
                                        <option value="<?php echo $vendor->vendor_id;?>"><?php echo $vendor->vendor_name;?></option>
                                        <?php }?>
                                    </select>
                          </div>
                        </div>
                        </div>
                      
                      
<div class="col-md-2">
    <div class="form-group row">
                          <label>Item Code</label>
                         <div class="col-sm-9" style="padding-left:0px !important;">
 <select class="form-control m-bot15" name="item_id[]" id="purchase_item" onchange="itemwisedetails(this)">
                                  <option value="">Select</option>
                                    <?php foreach($items as $item){?>
                                    <option value="<?php echo $item->item_sale_id;?>"  ><?php echo $item->item_sale_id;?></option>
                                    <?php }?>
                                </select>
</div> 
</div>

</div>
<div class="col-md-3">
                        <div class="form-group row">
                          <label>Quantity</label> 
                          
                           <input type="text" class="form-control" name="purchase_reference" placeholder="Quantity">
                          
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                         <center><br>
                          <input type="submit"  name="submit" value="Generate" class="btn btn-success"/> &nbsp; &nbsp;
                          <input type="reset"  name="submit" value="Clear" class="btn btn-danger"/>
                        </center>
                      </div>
                      </div>
                    </div>
</div>
</div>
</div>
</div>
</div>


 





