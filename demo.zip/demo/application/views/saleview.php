<style>
table td, table th{
  padding: 18px 10px !important;
}
</style>
<div class="content-wrapper">
          <div class="row">

           <?php foreach($sales as $sale) {
                       $sale_id=$sale->sale_id;
                        $site=$sale->site;
                       $sale_date=$sale->sale_date;
                        $order_no=$sale->order_no;
                        $eway_no=$sale->eway_no;
                          $vehicle_reg_no=$sale->vehicle_reg_no;
                       $customer_id=$sale->customer_id;
                       $transpotation=$sale->transpotation;
                       $sub_total=$sale->sub_total;
                    $sgst_percentage=$sale->sgst_percentage;
                    $sgst_value=$sale->sgst_value;
                   $cgst_percentage=$sale->cgst_percentage;
                    $cgst_value=$sale->cgst_value;
                      $igst_percentage=$sale->igst_percentage;
                    $igst_value=$sale->igst_value;
                       $sale_grand_total=$sale->sale_grand_total;
                    } ?>
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <center><h4 class="card-title">Sale Details</h4></center>
                  <form class="form-sample">
                    <p class="card-description">

                    </p>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label" style="padding-right: 0px !important;"> &nbsp;&nbsp;&nbsp;&nbsp;Date</label>
                          <div class="col-sm-8" style="padding-left: 0px !important;">
                            <input type="date" class="form-control" value="<?php echo date("Y-m-d");?>" name="sale_date" placeholder="Sale Date" readonly />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">Bill No.</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="sale_id" placeholder="sale Id" value="<?php echo $sale_id;?>" readonly>
                          </div>
                        </div>
                      </div>
                       <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label" style="padding-right: 0px !important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Order No.</label>
                          <div class="col-sm-7" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="order_no" placeholder="Order No" value="<?php echo $order_no;?>" readonly>
                          </div>
                        </div>
                      </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label" style="padding-right: 0px !important;">E - Way Bill No.</label>
                          <div class="col-sm-8"  style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="eway_no" placeholder="Eway No" value="<?php echo $eway_no;?>" readonly>
                          </div>
                        </div>
                      </div>
                    
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label" style="padding-right: 0px !important;">Vehicle Reg No.</label>
                          <div class="col-sm-8" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="vehicle_reg_no" placeholder="Vehicle Reg" value="<?php echo $vehicle_reg_no;?>" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">Site.</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="site" value="<?php echo $site;?>"  readonly />
                          </div>
                        </div>
                      </div>
                        <!--<div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label" style="padding-right: 0px !important;">Cuatomer ID</label>
                          <div class="col-sm-7" style="padding-left: 0px !important;">
                            <!--<input type="text" class="form-control" name="sale_vendor" value="<?php foreach($vendors as $vendor){ if ($vendor->vendor_id==$sale_vendor) {
                     echo $vendor->vendor_name; }}?>" readonly>
                            <input type="text" class="form-control" name="customer_id" readonly="readonly" value="<?php echo $customer_id;?>"/>
                          </div>
                        </div>
                      </div>-->
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label" style="padding-right: 0px !important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Customer &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Name</label>
                          <div class="col-sm-7" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="customer_name" readonly="readonly" id="customer_name" value="<?php foreach($customers as $customer){ if ($customer->customer_id==$customer_id) {
                     echo $customer->customer_name; }}?>"/>
                          </div>
                        </div>
                      </div>
                        <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label" style="padding-right: 0px !important;">Party GST</label>
                          <div class="col-sm-8" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" name="partygst" readonly="readonly" id="partygst" required="required" value="<?php foreach($customers as $customer){ if ($customer->customer_id==$customer_id) {
                     echo $customer->customer_gst; }}?>" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                          <thead>
                            <tr>
                               <th><center>S.no</center></th>

                              <th><center>Code</center></th>
                               <th><center>Hsn No.</center></th>
                               <th><center> Name</center></th>
                              
                              <th><center>Quantity</center></th>
                              <th><center>Per   Cost</center></th>
                              <th><center>Per Unit</center></th>
                              <th><center>Total Amount</center></th>
                            </tr>
                          </thead>
                        
                            <tbody>
                               <?php $i=1;  foreach($sales_items as $sale){?>
                              <tr>
                                <td><?php echo $i++;;?></td>
                                <td>
                                  <input type="text" class="form-control" id="sale_item" readonly name="item_id" value="<?php echo $sale->item_id;?>">
                                </td>
                                <td>
                                  <input type="text" class="form-control" id="hsn_no" readonly name="hsn_no" value="<?php echo $sale->hsn_no;?>">
                                </td>
                                <td> <input type="text" class="form-control"  readonly name="item_name" value="<?php echo $sale->item_name;?>"></td>
                                
                                <td><input type="text" class="form-control" readonly name="item_quanity" value="<?php echo $sale->item_quantity;?>"></td>
                                <td><input type="text" class="form-control" readonly name="item_price" value="<?php echo $sale->item_price;?>"></td>
                                <td><input type="text" class="form-control" readonly name="item_per" value="<?php echo $sale->item_per;?>"></td>
                                
                                 <td><input type="text" class="form-control" id="amount" placeholder="Total Amount" value="<?php echo $sale->total_amount;?>" readonly></td>
                              </tr>
                                <?php } ?>
                          </tbody>
                        </table>
                      </div>
                    </div>

               </div>
             <hr>
             <div class="row">
                      <div class="col-md-7">
                        <div class="form-group row">
                        
                          <label class="col-sm-7 col-form-label" style="padding-right: 0px !important;">Freight / Packing and forwading transpotation  </label>
                          <div class="col-sm-5" style="padding-left: 0px !important;">
                           <input type="text" class="form-control" id="transpotation" name="transpotation" pattern="[0-9]{1,10}"  value="<?php echo $transpotation;?>" readonly>
                          </div>
                          </div>
                        </div>
                        <div class="col-md-5">
                        <div class="form-group row">
                        
                          <label class="col-sm-4 col-form-label" style="padding-right: 0px !important;">Subtotal Amount</label>
                          <div class="col-sm-8" style="padding-left: 0px !important;">
                           <input type="text" class="form-control" id="item_total" name="item_total" readonly="readonly" value="<?php echo $sub_total;?>">
                          </div>
                          </div>
                        </div>
                      </div>
                 <hr>
                     
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">SGST</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                            
                             <input type="text" class="form-control" id="sgst_value" name="sgst_value"  value="<?php echo $sgst_value;?>" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">CGST </label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                          
                             <input type="text" class="form-control" id="cgst_value" name="cgst_value" placeholder="CGST" pattern="[0-9]{1-20}" readonly   value="<?php echo $cgst_value;?>">
                        </div>
                      </div>
                    </div>
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label" style="padding-right: 0px !important;">IGST</label>
                          <div class="col-sm-9" style="padding-left: 0px !important;">
                             <input type="text" class="form-control" id="igst_value" name="igst_value"   value="<?php echo $igst_value;?>" readonly >
                          </div>
                        </div>
                      </div>
                      
                      <div class="col-md-3">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label" style="padding-right: 0px !important;">Grand Total</label>
                          <div class="col-sm-7" style="padding-left: 0px !important;">
                            <input type="text" class="form-control" id="sale_grand_total" placeholder="Grand Total" readonly name="sale_grand_total"   value="<?php echo $sale_grand_total;?>">
                          </div>
                        </div>
                      </div>
                    </div><hr>
                  <!--<div class="row">
                      
                    <div class="col-md-12">
                        <div class="form-group row"  style="float: right;">
                        <a href="<?php $url='sale_print/'.$sale_id; echo $url; ?>"  class="btn btn-warning" target="_blank">Print</a>
                            <button type="submit" class="btn btn-warning">Print View</button>
                        </div>
                      </div>
                    
                
                      
                    </div>-->
                 
                
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

       