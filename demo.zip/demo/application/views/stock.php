<div class="content-wrapper">
          <div class="row">
          	 <!--<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <?php echo $this->session->flashdata('errorMessage') ?>
                  <?php echo $this->session->flashdata('successMessage')?>
                	<a href="<?php echo base_url(); ?>Sales/addsales" class="btn btn-success">Add New Sale</a>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
               <!-- <center><h4 class="card-title">Stock List</h4></center>-->
               <br></br>
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped"  id="table_for_pagination">
                      <thead>
                        <tr>
                          <th><center> 
                            S.No</center> 
                          </th>
                          <th><center> 
                            Date</center> 
                          </th>
                          <th><center> 
                            Total Stock</center> 
                          </th>
                          <th><center> 
                            Current Stock</center> 
                          </th>
                         
                        </tr>
                      </thead>
                      <tbody>
                        <?php  $i=sizeof($sales); foreach($sales as $sale){?>
                        <tr>
                         <td><center> <?php echo $i--;?></center> </td>
                          <td><center> 
                            <?php echo date('d-m-Y', strtotime($sale->sale_date));?></center> </td>
                          <td><center> 
                           <?php echo $sale->sale_id;?></center> 
                          </td>
                          <td><center> 
                           <?php echo $sale->customer_id;?></center> 
                          </td>
                          <td><center> 
                             <?php echo $sale->sale_grand_total;?></center> 
                          </td>
                          <td><center> 
                             <a href="<?php echo base_url() ?>Sales/sale_view?sale_id=<?php echo $sale->sale_id;?>" class="btn btn-info">
                             View</a>
                            <a href="<?php echo base_url() ?>Sales/sale_print?sale_id=<?php echo $sale->sale_id;?>" class="btn btn-success" target="_blank">
                              Print</a></center> 
                          </td>
                        </tr>
                      <?php }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>