<div class="content-wrapper">
          <div class="row">
           <!--<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                  <a href="<?php echo base_url(); ?>Purchase/purchase_now" class="btn btn-success">Add Purchase/Prod.</a>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <!-- <a href="<?php echo base_url(); ?>Purchase/purchase_now" class="btn btn-success">Add Purchase/Prod.</a>
                     &nbsp;&nbsp;&nbsp;<a href="<?php echo base_url(); ?>Welcome/all_purchase" class="btn btn-success">All purchase</a>-->
                  <center><h4 class="card-title">Stock List</h4></center>
                 
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <!--<th>
                            S.No
                          </th>
                         -->
                          <th>
                          <center>Date</center>
                          </th>
                          
                          <th>
                           <center>Purchase</center>
                          </th>
                         
                         
                           <th>
                            <center>Sales</center>
                          </th>
                           <th>
                            <center>Current Stock</center>
                          </th>
                           <th>
                            <center>Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><center> <?php echo date('d-m-Y');?></center></td>
                          <!--td><center><?php echo $opening_stock_total;?></center></td-->
                          <td><center><?php 
                            if($purchase_stock_total)
                            {
                              echo $purchase_stock_total;
                            }
                            else{
                              echo 0;;
                            }
                            ?></center></td>
                           
                          
                          <!--td><center><?php echo $opening_stock_total+$purchase_stock_total;?></center></td-->
                           <td><center><?php 
                            if($sales_stock_total)
                            {
                              echo $sales_stock_total;
                            }
                            else{
                              echo 0;;
                            }
                            ?></center></td>
                          
                           <td><center><?php 
                            if($total_item_stock)
                            {
                              echo $total_item_stock;
                            }
                            else{
                              echo 0;;
                            }
                            ?></center></td>
                           <td> <center><a href="<?php echo base_url() ?>Stock/detailed_view" class="btn btn-primary">
                                    View</a></center></td>
                        </tr>
                       <!--   <?php  $i=1; foreach($vendor_purchases as $vendor_purchase){?>
                        <tr>
                          <td><?php echo $i++;;?></td>-->
                          <!-- <?php foreach($vendors as $vendor){
                              if ($vendor->vendor_id==$vendor_purchase->purchase_vendor) { ?>
                                <td><?php echo $vendor->vendor_name;?></td>
                               <?php }  }?>
                            <td><?php echo $vendor_purchase->each_vendor_purchase;?></td>
                            <td><?php echo round($vendor_purchase->total);?></td>
                          <td>
                             <a href="<?php echo base_url() ?>Purchase/purchase_vendordetailed?vendors_id=<?php echo $vendor_purchase->purchase_vendor;?>" class="btn btn-primary">
                                    View</a>
                                    <a href="<?php echo base_url() ?>Eachview/purchase_print?purchase_id=<?php echo "";?>" class="btn btn-success" target="_blank">
                                    <i class="fa fa-print"></i></a>
                          </td>
                        </tr>
                      <?php }?>-->
                     
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>