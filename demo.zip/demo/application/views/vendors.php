<div class="content-wrapper">
          <div class="row">
            <!-- <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                   <button type="submit" onclick="add_vendor()" class="btn btn-success">Add New Vendor</button>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                   <button type="submit" onclick="add_vendor()" class="btn btn-success">Add New Vendor</button>
                   <br></br>
                 <!-- <center><h4 class="card-title">Vendors</h4></center>-->
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="table_for_pagination">
                      <thead>
                        <tr>
                         <!-- <th>
                            S.No
                          </th>-->
                          
                          <th><center>
                             ID</center>
                          </th>
                          <th><center>
                             Name</center>
                          </th>
                          <th><center>
                             Contact</center>
                          </th>
                           <th><center>Address</center></th>
                           <th><center>GST</center></th>
                           <th><center>Status</center></th>
                          <th><center>
                            Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $i=sizeof($vendors); foreach($vendors as $vendor){?>
                     <tr>
                      <!--<td><?php echo $i--;;?></td>-->
                         <td><center><?php echo $vendor->vendor_id;?></center></td>
                         <td><center><?php echo $vendor->vendor_name;?></center></td>
                                 <td><center><?php echo $vendor->vendor_contact;?></center></td>
                                <td><center><?php echo $vendor->vendor_address;?></center></td>
                                 <td><center><?php echo $vendor->vendor_gst;?></center></td>
                               <td><center>
                           
                             <button 
                             class="btn btn-<?php if($vendor->status=="1"){echo "success";}else{echo "danger";}?>" 
                                onclick="edit_vendorstatus(<?php echo $vendor->vendor_id;?>)" data-toggle="tooltip" 
                                title="<?php if($vendor->status=="1"){echo "Inactivate";}else{echo "Activate";}?>">
                                 <?php if($vendor->status=="1"){echo "Active";}else{echo "Inactive";}?>
                             </button></center></td> 
                                <td><center>
                                    <button class="btn btn-warning" onclick="edit_vendor(<?php echo $vendor->vendor_id;?>)">Edit</button>
                                    <!--<button class="btn btn-danger" onclick="delete_vendor(<?php echo $vendor->vendor_id;?>)"><i class="fa fa-remove"></i></button>-->

</center>
                                </td>
                      </tr>
                     <?php }?>
                       
                   
                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>
 
  
    <script type="text/javascript">
 
    var save_method; //for save method string
    var table;


    function add_vendor()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_vendor(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('index.php/Vendors/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="vendor_id"]').val(data.vendor_id);
            $('[name="vendor_name"]').val(data.vendor_name);
            $('[name="vendor_contact"]').val(data.vendor_contact);
            $('[name="vendor_address"]').val(data.vendor_address);
            $('[name="vendor_gst"]').val(data.vendor_gst);
           


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit vendor'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('index.php/Vendors/vendor_add')?>";
      }
      else
      {
        url = "<?php echo site_url('index.php/Vendors/vendor_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
    }

    function delete_vendor(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/Vendors/vendor_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

      }
    }
function edit_vendorstatus(id)
    {
      if(confirm('Are you sure want to update the status'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/Vendors/edit_vendorstatus')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Cannot update the unit Status');
            }
        });

      }
    }
  </script>

<!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        
        <h3 class="modal-title">Add Vendor</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="vendor_id"/>
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-12">Vendor Name <span style="color: red">*</span></label>
              <div class="col-md-12">
                <input name="vendor_name" placeholder="vendor Name" class="form-control" type="text" required>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-12">Vendor Contact <span style="color: red">*</span></label>
              <div class="col-md-12">
                <input name="vendor_contact" placeholder="vendor Contact" class="form-control" type="text" required>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-12">Vendor Address<span style="color: red">*</span></label>
              <div class="col-md-12">
                  <input name="vendor_address" placeholder="vendor Address" class="form-control" type="text" required>

              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-12">Vendor GST<span style="color: red">*</span></label>
              <div class="col-md-12">
                  <input name="vendor_gst" placeholder="vendor GST" class="form-control" type="text" required>

              </div>
            </div>
                       
          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->