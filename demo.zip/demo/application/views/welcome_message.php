<style>
    p{
        font-size:15px;
    }
    .text-muted{
        font-size:13.5px;
    }
</style>
      <!-- partial -->

        <div class="content-wrapper">
         
          <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-cube text-danger icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Sales</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo round($total_sales_count); ?></h3>
                      </div>
                    </div>
                  </div>
                    <a href="<?php echo base_url(); ?>Welcome/total_sales" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-alert-octagon mr-1" aria-hidden="true"></i> <span style="color: #508de5;">Total Sales Invoices</span>
                  </p>
                </a>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                      <div class="float-left">
                      <i class="mdi mdi-cube text-danger icon-lg"></i>
                    </div>
            <div class="float-right">
                      <p class="mb-0 text-right">Sales Amount</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo round($total_sales_amount); ?></h3>
                      </div>
                    </div>
                    </div>
                    <a href="<?php echo base_url(); ?>Welcome/total_sales" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-alert-octagon mr-1" aria-hidden="true"></i> <span style="color: #508de5;">Total Sales Amount</span>
                  </p>
                </a>
                </div>
              </div>
            </div>
                    
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-poll-box text-success icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Monthly Sales</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo round($month_sales_count); ?></h3>
                      </div>
                    </div>
                  </div>
                   <a href="<?php echo base_url(); ?>Welcome/month_sales" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i><span style="color: #508de5;">Monthly Sales Invoices</span>
                  </p>
                </a>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-poll-box text-success icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Monthly Sales Amt</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo round($month_sales_amount); ?></h3>
                      </div>
                    </div>
                  </div>
                   <a href="<?php echo base_url(); ?>Welcome/month_sales" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i><span style="color: #508de5;">Monthly Sales Amount</span>
                  </p>
                </a>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-receipt text-warning icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Purchase</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo round($total_purchase_count); ?></h3>
                      </div>
                    </div>
                  </div>
                    <a href="<?php echo base_url(); ?>Purchase/all_purchase" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-bookmark-outline mr-1" aria-hidden="true"></i> <span style="color: #508de5;">Total Purchase</span>
                  </p>
                </a>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-receipt text-warning icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Purchase Amount</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo round($total_purchase_amount); ?></h3>
                      </div>
                    </div>
                  </div>
                    <a href="<?php echo base_url(); ?>Purchase/all_purchase" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-bookmark-outline mr-1" aria-hidden="true"></i> <span style="color: #508de5;">Total Purchase Amount</span>
                  </p>
                </a>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi  mdi-cube text-primary icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Current Stock</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo $total_stock; ?></h3>
                      </div>
                    </div>
                  </div>
                  <a href="<?php echo base_url(); ?>Stock/detailed_view" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-reload mr-1" aria-hidden="true"></i><span style="color: #508de5;"> Current Stock Details</span>
                  </p>
                  </a>
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-account-location text-info icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Total Customers</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"><?php echo $total_customers; ?></h3>
                      </div>
                    </div>
                  </div>
                  <a href="<?php echo base_url(); ?>Customers" style="text-decoration: none;">
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-reload mr-1" aria-hidden="true"></i><span style="color: #508de5;"> Total Customers</span>
                  </p>
                  </a>
                </div>
              </div>
            </div>
            
          </div>
        
         
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       