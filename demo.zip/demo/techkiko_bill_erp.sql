-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 27, 2018 at 12:19 PM
-- Server version: 5.6.41-84.1-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `techkiko_bill_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comp_name` varchar(255) NOT NULL,
  `comp_add` varchar(255) NOT NULL,
  `comp_gst` varchar(255) NOT NULL,
  `term_cond` varchar(700) NOT NULL,
  `admin_photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `email`, `comp_name`, `comp_add`, `comp_gst`, `term_cond`, `admin_photo`) VALUES
(1, 'admin@example.com', '$2y$10$1AiWQ5p4cOK8GdGn1OCWx.yMOcEu5DK4sezjKlyE4pZF4xnjV79.6', 'Vijaycement@techkshetrainfo.com', 'Vijaya Cements Bagalkot', 'Bagalkot', 'GST12343', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `registration_date` date NOT NULL,
  `customer_id` varchar(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_gst` varchar(100) NOT NULL,
  `customer_contact` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_address1` varchar(500) NOT NULL,
  `customer_address2` varchar(500) NOT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `city` varchar(300) NOT NULL,
  `state` varchar(110) DEFAULT NULL,
  `country` varchar(110) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

 

-- --------------------------------------------------------

--
-- Table structure for table `gst`
--

CREATE TABLE `gst` (
  `gst_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gst`
--



-- --------------------------------------------------------

--
-- Table structure for table `itemwise_purchases`
--

CREATE TABLE `itemwise_purchases` (
  `id` int(11) NOT NULL,
  `purchase_id` varchar(11) NOT NULL,
  `created_date` date NOT NULL,
  `item_id` varchar(100) NOT NULL,
  `hsn_no` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `item_price` double NOT NULL,
  `item_per` varchar(100) NOT NULL,
  `item_sgst_percentage` int(11) NOT NULL,
  `item_cgst_percentage` int(11) NOT NULL,
  `item_igst_percentage` int(11) NOT NULL,
  `total_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itemwise_purchases`
--



-- --------------------------------------------------------

--
-- Table structure for table `itemwise_sales`
--

CREATE TABLE `itemwise_sales` (
  `id` int(11) NOT NULL,
  `sale_id` varchar(11) NOT NULL,
  `created_date` date NOT NULL,
  `item_id` varchar(100) NOT NULL,
  `hsn_no` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `item_price` double NOT NULL,
  `item_per` varchar(255) NOT NULL,
  `item_sgst_percentage` int(11) NOT NULL,
  `item_cgst_percentage` int(11) NOT NULL,
  `item_igst_percentage` int(11) NOT NULL,
  `total_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itemwise_sales`
--


-- --------------------------------------------------------

--
-- Table structure for table `purchasecategory`
--

CREATE TABLE `purchasecategory` (
  `category_purchase_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `pcategory` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchaseitems`
--

CREATE TABLE `purchaseitems` (
  `item_purchase_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `pitemname` varchar(100) NOT NULL,
  `pitemdes` varchar(255) NOT NULL DEFAULT 'Placement',
  `pprice` varchar(100) DEFAULT NULL,
  `pitemgst` varchar(100) NOT NULL,
  `category` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_id` varchar(11) NOT NULL,
  `purchase_vendor` varchar(100) NOT NULL,
  `purchase_reference` varchar(100) NOT NULL,
  `total_items` varchar(100) NOT NULL,
  `sub_total` double DEFAULT NULL,
  `sgst_percentage` int(11) NOT NULL,
  `sgst_value` int(11) NOT NULL,
  `cgst_percentage` int(11) NOT NULL,
  `cgst_value` int(11) NOT NULL,
  `igst_percentage` int(11) NOT NULL,
  `igst_value` int(11) NOT NULL,
  `purchase_grand_total` double NOT NULL,
  `purchase_upload` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases`
--



-- --------------------------------------------------------

--
-- Table structure for table `saleitems`
--

CREATE TABLE `saleitems` (
  `item_sale_id` int(11) NOT NULL,
  `item_id` varchar(255) NOT NULL,
  `created_date` date NOT NULL,
  `sitemname` varchar(255) NOT NULL,
  `hsn_no` varchar(100) NOT NULL,
  `sitemdes` varchar(255) NOT NULL,
  `sprice` int(100) NOT NULL DEFAULT '0',
  `pprice` int(11) NOT NULL DEFAULT '0',
  `sper` varchar(100) NOT NULL,
  `sgst` int(11) NOT NULL,
  `cgst` int(11) NOT NULL,
  `igst` varchar(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `opening_stock` int(11) NOT NULL,
  `current_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saleitems`
--



-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `sale_date` date NOT NULL,
  `sale_id` varchar(11) NOT NULL,
  `order_no` varchar(100) NOT NULL,
  `eway_no` varchar(255) NOT NULL,
  `vehicle_reg_no` varchar(255) NOT NULL,
  `site` varchar(255) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `total_items` varchar(100) NOT NULL,
  `transpotation` double NOT NULL,
  `sub_total` double DEFAULT NULL,
  `sgst_percentage` double DEFAULT NULL,
  `sgst_value` double DEFAULT NULL,
  `cgst_percentage` double NOT NULL,
  `cgst_value` double NOT NULL,
  `igst_percentage` double NOT NULL,
  `igst_value` double NOT NULL,
  `sale_grand_total` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--



-- --------------------------------------------------------

--
-- Table structure for table `salescategory`
--

CREATE TABLE `salescategory` (
  `category_sales_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `scategory` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salescategory`
--


-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL,
  `unitname` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--



-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `vendor_id` int(11) NOT NULL,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_contact` int(11) NOT NULL,
  `vendor_address` varchar(50) NOT NULL,
  `vendor_gst` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`vendor_id`, `vendor_name`, `vendor_contact`, `vendor_address`, `vendor_gst`, `status`) VALUES
(1, 'Own Production', 2147483647, 'Bagalkot', '12345', 1);


--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`,`customer_id`);

--
-- Indexes for table `gst`
--
ALTER TABLE `gst`
  ADD PRIMARY KEY (`gst_id`);

--
-- Indexes for table `itemwise_purchases`
--
ALTER TABLE `itemwise_purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itemwise_sales`
--
ALTER TABLE `itemwise_sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasecategory`
--
ALTER TABLE `purchasecategory`
  ADD PRIMARY KEY (`category_purchase_id`);

--
-- Indexes for table `purchaseitems`
--
ALTER TABLE `purchaseitems`
  ADD PRIMARY KEY (`item_purchase_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `purchase_id` (`purchase_id`);

--
-- Indexes for table `saleitems`
--
ALTER TABLE `saleitems`
  ADD PRIMARY KEY (`item_sale_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`,`sale_id`);

--
-- Indexes for table `salescategory`
--
ALTER TABLE `salescategory`
  ADD PRIMARY KEY (`category_sales_id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `gst`
--
ALTER TABLE `gst`
  MODIFY `gst_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `itemwise_purchases`
--
ALTER TABLE `itemwise_purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `itemwise_sales`
--
ALTER TABLE `itemwise_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `purchasecategory`
--
ALTER TABLE `purchasecategory`
  MODIFY `category_purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `purchaseitems`
--
ALTER TABLE `purchaseitems`
  MODIFY `item_purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `saleitems`
--
ALTER TABLE `saleitems`
  MODIFY `item_sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `salescategory`
--
ALTER TABLE `salescategory`
  MODIFY `category_sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
